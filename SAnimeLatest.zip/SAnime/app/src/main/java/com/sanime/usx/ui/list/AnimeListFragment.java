package com.sanime.usx.ui.list;

import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.kevinsawicki.http.HttpRequest;
import com.github.ybq.android.spinkit.SpinKitView;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.StringCallback;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class AnimeListFragment extends Fragment {
    private AnimeListViewModel slideshowViewModel;
    public View roots;
    public DownloadTask downloadTask;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(AnimeListViewModel.class);
        View root = inflater.inflate(R.layout.fragment_animelist, container, false);
        final ImageButton refresh = root.findViewById(R.id.refreshinternet);
        roots = root;
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downloadTask = new DownloadTask();
                downloadTask.execute(MainActivity.getApi("data/anime_a.zip"));
            }
        });
        downloadTask = new DownloadTask();
        downloadTask.execute(MainActivity.getApi("data/anime_a.zip"));
        slideshowViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {

            }
        });
        return root;
    }
    private class DownloadTask extends AsyncTask<String, Long, File> {
        protected File doInBackground(String... urls) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setUI(true, roots, false, "");
                }
            });
            try {
                HttpRequest request =  HttpRequest.get(urls[0]);
                File file = null;
                if (request.ok()) {
                    file = File.createTempFile("download", ".zip");
                    request.receive(file);
                    publishProgress(file.length());
                }
                return file;
            } catch (HttpRequest.HttpRequestException | IOException exception) {
                return null;
            }
        }

        protected void onProgressUpdate(Long... progress) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setUI(true, roots, false, "");
                }
            });
        }
        protected void onPostExecute(File file) {
            downloadTask.cancel(true);
            if (file != null) {
                ZipFile zipFile = null;
                try {
                    zipFile = new ZipFile(file.getAbsoluteFile());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Enumeration<? extends ZipEntry> entries = zipFile.entries();

                while(entries.hasMoreElements()){
                    ZipEntry entry = entries.nextElement();
                    try {
                        InputStream stream = zipFile.getInputStream(entry);
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                setUI(false, roots, false, getContent(stream));
                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                setUI(false,roots,true,"");
                            }
                        });
                    }
                }
                file.delete();
            } else {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setUI(false,roots,true,"");
                    }
                });
            }
        }
    }
    public String getContent(InputStream file) {
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(file, "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        }
        catch (IOException e) {
            Log.e("error get string",e.getMessage());
        }
        return text.toString();
    }
    public void setUI(Boolean isLoading,View root,Boolean isError,String stringResults) {
        final RecyclerView rvContacts = root.findViewById(R.id.animelist);
        final LinearLayout spankit = root.findViewById(R.id.spankit);
        final SpinKitView spinKitView = root.findViewById(R.id.spin_kit);
        final CardView nointernet = root.findViewById(R.id.nointernet);
        if (isLoading) {
            nointernet.setVisibility(View.GONE);
            spankit.setVisibility(View.VISIBLE);
            spinKitView.setVisibility(View.VISIBLE);
        } else {
            if (isError) {
                spankit.setVisibility(View.VISIBLE);
                spinKitView.setVisibility(View.GONE);
                nointernet.setVisibility(View.VISIBLE);
            } else {
                spankit.setVisibility(View.GONE);
                spinKitView.setVisibility(View.GONE);
                try {
                    GridLayoutManager gridLayoutManager;
                    if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                        gridLayoutManager = new GridLayoutManager(getContext(),2, LinearLayoutManager.VERTICAL,false);
                    }
                    else{
                        gridLayoutManager = new GridLayoutManager(getContext(),4, LinearLayoutManager.VERTICAL,false);
                    }
                    rvContacts.setLayoutManager(gridLayoutManager); // set LayoutManager to RecyclerView
                    ArrayList<Anime> contacts = new ArrayList<Anime>();
                    JSONArray array = new JSONArray(stringResults);
                    ContactsAdapter adapter = new ContactsAdapter(contacts);
                    for (int i = 0; i < array.length(); i++) {
                        contacts.add(new Anime(array.getJSONObject(i).getString("name"),array.getJSONObject(i).getString("status"),array.getJSONObject(i).getString("image"),array.getJSONObject(i).getString("id")));
                    }
                    rvContacts.setAdapter(adapter);
                    rvContacts.getAdapter().notifyDataSetChanged();
                }catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}