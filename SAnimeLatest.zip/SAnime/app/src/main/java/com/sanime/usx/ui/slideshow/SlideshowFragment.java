package com.sanime.usx.ui.slideshow;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.sanime.usx.ClickInterface;
import com.sanime.usx.MainActivity;
import com.sanime.usx.News;
import com.sanime.usx.R;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.sanime.usx.adapter.SearchAdapter;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonArrayCallback;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class SlideshowFragment extends Fragment {

    private SlideshowViewModel slideshowViewModel;
    public static String URLS = "";
    public static String CONTENT = "";
    public static String TIME = "";
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(SlideshowViewModel.class);
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);
        final SwipeRefreshLayout swipeRefreshLayout = root.findViewById(R.id.refresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                setUi(getContext(),root,swipeRefreshLayout);
            }
        });
        setUi(getContext(),root,swipeRefreshLayout);
        return root;
    }
    public void setUi(Context context, View view,SwipeRefreshLayout swipeRefreshLayout) {
        swipeRefreshLayout.setRefreshing(true);
        HttpAgent.get(MainActivity.getApi("data/user/news.json"))
                .setTimeOut(10000)
                .goJsonArray(new JsonArrayCallback() {
                    @Override
                    protected void onDone(boolean success, JSONArray jsonResults) {
                        if (success) {
                            swipeRefreshLayout.setRefreshing(false);
                            try {
                                GridLayoutManager gridLayoutManager3;
                                RecyclerView rvContacts3 = view.findViewById(R.id.rvContacts);
                                if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                                    gridLayoutManager3 = new GridLayoutManager(context,2, LinearLayoutManager.VERTICAL,false);
                                }
                                else{
                                    gridLayoutManager3 = new GridLayoutManager(context,4, LinearLayoutManager.VERTICAL,false);
                                }
                                rvContacts3.setLayoutManager(gridLayoutManager3); // set LayoutManager to RecyclerView
                                ArrayList<Anime> contacts3 = new ArrayList<Anime>();
                                SearchAdapter adapter3 = new SearchAdapter(contacts3, new ClickInterface() {
                                    @Override
                                    public void itemClicked(int position) {
                                        try {
                                            URLS = jsonResults.getJSONObject(position).getString("id");
                                            CONTENT = jsonResults.getJSONObject(position).getString("title");
                                            TIME = jsonResults.getJSONObject(position).getString("time");
                                            startActivity(new Intent(context, News.class));
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                                for (int is = 0; is < jsonResults.length(); is++) {
                                    contacts3.add(new Anime(jsonResults.getJSONObject(is).getString("title"),jsonResults.getJSONObject(is).getString("time"),jsonResults.getJSONObject(is).getString("image"),jsonResults.getJSONObject(is).getString("id")));
                                }
                                rvContacts3.setAdapter(adapter3);
                                rvContacts3.getAdapter().notifyDataSetChanged();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }else {
                            setUi(context,view,swipeRefreshLayout);
                        }
                    }
                });
    }
}