package com.sanime.usx.ui.home;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.sanime.usx.ui.community.CommunityFragment;
import com.sanime.usx.view.image.imageToBitmap;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonArrayCallback;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.sanime.usx.MainActivity.getApi;
import static com.sanime.usx.MainActivity.viewPagerTab;

public class HomeFragment extends Fragment {
    private FragmentActivity myContext;
    private HomeViewModel homeViewModel;
    public static ViewPager viewPager;
    public static String response = "";
    public static View viewss;
    public static Context contexts;
    public static DemoCollectionPagerAdapter demoCollectionPagerAdapters;
    @Override
    public void onAttach(Activity activity) {
        myContext=(FragmentActivity) activity;
        super.onAttach(activity);
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        DemoCollectionPagerAdapter demoCollectionPagerAdapter = new DemoCollectionPagerAdapter(getChildFragmentManager());
        demoCollectionPagerAdapters = demoCollectionPagerAdapter;
        contexts = getContext();
        setUI(view,demoCollectionPagerAdapter,getContext());
    }
    public static void setUI(final View view, final DemoCollectionPagerAdapter demoCollectionPagerAdapter, final Context context) {
        if (MainActivity.ISRES) {
            viewss = view;
            viewPager = view.findViewById(R.id.viewpager);
            viewPager.setAdapter(demoCollectionPagerAdapter);
            viewPagerTab.setViewPager(viewPager);
            response = MainActivity.RESPONSE;
        } else {
            final LoadingDialog dl = new LoadingDialog(context);
            dl.setLoadingText("يرجى الأنتظار");
            dl.show();
            HttpAgent.get(getApi("data/v10.php"))
                    .setTimeOut(10000)
                    .goString(new StringCallback() {
                        @Override
                        protected void onDone(boolean success, String stringResults) {
                            if (success) {
                                if (stringResults.isEmpty()) {
                                    try {
                                        dl.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                                    builder.setMessage("توجد مشكلة في الشبكة حاول مجددا");
                                    builder.setCancelable(false);
                                    builder.setNegativeButton("اعادة", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            setUI(view,demoCollectionPagerAdapter,context);
                                            dialog.dismiss();
                                        }
                                    });
                                    builder.create().show();
                                } else {
                                    if (!imageToBitmap.DDA(stringResults).contains("error make image"))
                                    {
                                        dl.close();
                                        viewss = view;
                                        viewPager = view.findViewById(R.id.viewpager);
                                        viewPager.setAdapter(demoCollectionPagerAdapter);
                                        viewPagerTab.setViewPager(viewPager);
                                        response = imageToBitmap.DDA(stringResults);
                                        MainActivity.ISRES = true;
                                        MainActivity.RESPONSE = response;
                                    }
                                }
                            } else {
                                try {
                                    dl.close();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                                builder.setMessage("توجد مشكلة في الشبكة حاول مجددا");
                                builder.setCancelable(false);
                                builder.setNegativeButton("اعادة", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setUI(view,demoCollectionPagerAdapter,context);
                                    dialog.dismiss();
                                }
                                });
                                builder.create().show();
                            }
                        }
                    });
        }
    }
    @Override
    public void onResume() {
        super.onResume();
    }
    public class DemoCollectionPagerAdapter extends FragmentStatePagerAdapter {
        public DemoCollectionPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {
            Fragment fragment = new DemoObjectFragment();
            Bundle args = new Bundle();
            // Our object is just an integer :-P
            args.putInt(DemoObjectFragment.ARG_OBJECT, i + 1);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            CharSequence string = "";
            switch (position) {
                case 0:
                    string = getString(R.string.tab_text_1);
                    break;
                case 1:
                    string = getString(R.string.tab_text_2);
                    break;
                case 2:
                    string = getString(R.string.tab_text_3);
                    break;
            }
            return string;
        }
    }
    public static class DemoObjectFragment extends Fragment {
        public static final String ARG_OBJECT = "object";

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            Bundle args = getArguments();
            View view;
            switch (args.getInt("object")) {
                case 1:
                    view = inflater.inflate(R.layout.fragment_pager_list, container, false);
                    break;
                case 2:
                    view = inflater.inflate(R.layout.fragment_pager_list2, container, false);
                    break;
                case 3:
                    view = inflater.inflate(R.layout.fragment_pager_list3, container, false);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + args.getInt("object"));
            }
            return view;
        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            RecyclerView rvContacts = view.findViewById(R.id.rvContacts);
            RecyclerView rvContacts2 = view.findViewById(R.id.rvContacts2);
            RecyclerView rvContacts3 = view.findViewById(R.id.rvContacts3);
            Bundle args = getArguments();
            MainActivity.ISRES = true;
            MainActivity.RESPONSE = response;
            try {
                switch (args.getInt("object")) {
                    case 1:
                        GridLayoutManager gridLayoutManager;
                        if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                            gridLayoutManager = new GridLayoutManager(getContext(),2, LinearLayoutManager.VERTICAL,false);
                        }
                        else{
                            gridLayoutManager = new GridLayoutManager(getContext(),4, LinearLayoutManager.VERTICAL,false);
                        }
                        rvContacts.setLayoutManager(gridLayoutManager); // set LayoutManager to RecyclerView
                        ArrayList<Anime> contacts = new ArrayList<Anime>();
                        JSONObject obj = new JSONObject(response);
                        if (obj.getString("type").contains("pin")) {
                            CommunityFragment.showPin(obj.getJSONObject("pin"),getContext(),obj.getBoolean("close"));
                        }
                        ContactsAdapter adapter = new ContactsAdapter(contacts);
                        for (int i = 0; i < obj.getJSONArray("latest").length(); i++) {
                            View views =  getLayoutInflater().inflate(R.layout.lists, null, false);
                            final TextView title = views.findViewById(R.id.series_title);
                            final TextView title2 = views.findViewById(R.id.title2);
                            final ImageView img = views.findViewById(R.id.series_image);
                            title2.setText(obj.getJSONArray("latest").getJSONObject(i).getString("epName"));
                            title.setText(obj.getJSONArray("latest").getJSONObject(i).getString("name"));
                            Glide.with(getContext()).load(Uri.parse(obj.getJSONArray("latest").getJSONObject(i).getString("image"))).into(img);
                            views.setId(i);
                            contacts.add(new Anime(obj.getJSONArray("latest").getJSONObject(i).getString("name"),obj.getJSONArray("latest").getJSONObject(i).getString("epName"),obj.getJSONArray("latest").getJSONObject(i).getString("image"),obj.getJSONArray("latest").getJSONObject(i).getString("id")));
                        }
                        rvContacts.setAdapter(adapter);
                        rvContacts.getAdapter().notifyDataSetChanged();
                        break;
                    case 2:
                        GridLayoutManager gridLayoutManager2;
                        if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                            gridLayoutManager2 = new GridLayoutManager(getContext(),2, LinearLayoutManager.VERTICAL,false);
                        }
                        else{
                            gridLayoutManager2 = new GridLayoutManager(getContext(),4, LinearLayoutManager.VERTICAL,false);
                        }
                        rvContacts2.setLayoutManager(gridLayoutManager2); // set LayoutManager to RecyclerView
                        ArrayList<Anime> contacts2 = new ArrayList<Anime>();
                        JSONObject obj2 = new JSONObject(response);
                        ContactsAdapter adapter2 = new ContactsAdapter(contacts2);
                        for (int i = 0; i < obj2.getJSONArray("foryou").length(); i++) {
                            View views =  getLayoutInflater().inflate(R.layout.lists, null, false);
                            final TextView title = views.findViewById(R.id.series_title);
                            final TextView title2 = views.findViewById(R.id.title2);
                            final ImageView img = views.findViewById(R.id.series_image);
                            title2.setText(obj2.getJSONArray("foryou").getJSONObject(i).getString("status"));
                            title.setText(obj2.getJSONArray("foryou").getJSONObject(i).getString("name"));
                            Glide.with(getContext()).load(Uri.parse(obj2.getJSONArray("foryou").getJSONObject(i).getString("image"))).into(img);
                            views.setId(i);
                            contacts2.add(new Anime(obj2.getJSONArray("foryou").getJSONObject(i).getString("name"),obj2.getJSONArray("foryou").getJSONObject(i).getString("status"),obj2.getJSONArray("foryou").getJSONObject(i).getString("image"),obj2.getJSONArray("foryou").getJSONObject(i).getString("id")));
                        }
                        rvContacts2.setAdapter(adapter2);
                        rvContacts2.getAdapter().notifyDataSetChanged();
                        break;
                    case 3:
                        GridLayoutManager gridLayoutManager3;
                        if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                            gridLayoutManager3 = new GridLayoutManager(getContext(),2, LinearLayoutManager.VERTICAL,false);
                        }
                        else{
                            gridLayoutManager3 = new GridLayoutManager(getContext(),4, LinearLayoutManager.VERTICAL,false);
                        }
                        rvContacts3.setLayoutManager(gridLayoutManager3); // set LayoutManager to RecyclerView
                        ArrayList<Anime> contacts3 = new ArrayList<Anime>();
                        JSONObject obj3 = new JSONObject(response);
                        ContactsAdapter adapter3 = new ContactsAdapter(contacts3);
                        for (int i = 0; i < obj3.getJSONArray("top").length(); i++) {
                            View views =  getLayoutInflater().inflate(R.layout.lists, null, false);
                            final TextView title = views.findViewById(R.id.series_title);
                            final TextView title2 = views.findViewById(R.id.title2);
                            final ImageView img = views.findViewById(R.id.series_image);
                            title2.setText(obj3.getJSONArray("top").getJSONObject(i).getString("name"));
                            title.setText(obj3.getJSONArray("top").getJSONObject(i).getString("title"));
                            Glide.with(getContext()).load(Uri.parse(obj3.getJSONArray("top").getJSONObject(i).getString("image"))).into(img);
                            views.setId(i);
                            contacts3.add(new Anime(obj3.getJSONArray("top").getJSONObject(i).getString("title"),obj3.getJSONArray("top").getJSONObject(i).getString("name"),obj3.getJSONArray("top").getJSONObject(i).getString("image"),obj3.getJSONArray("top").getJSONObject(i).getString("id")));
                        }
                        rvContacts3.setAdapter(adapter3);
                        rvContacts3.getAdapter().notifyDataSetChanged();
                        break;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                try {
                    setUI(viewss,demoCollectionPagerAdapters,contexts);
                } catch (Exception E) {
                    E.printStackTrace();
                }
            }
        }
    }
}