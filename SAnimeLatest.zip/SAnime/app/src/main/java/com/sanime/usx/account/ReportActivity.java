package com.sanime.usx.account;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.sanime.usx.AnimeUtil;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.info.InfoActivity;
import com.sanime.usx.view.CircleImageView;
import com.sanime.usx.view.image.imageToBitmap;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonArrayCallback;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.sanime.usx.MainActivity.getApi;
import static com.sanime.usx.MainActivity.showMessage;
import static com.sanime.usx.ui.community.CommunityFragment.getLineCount;
import static com.sanime.usx.ui.community.CommunityFragment.newLine;
import static com.sanime.usx.ui.community.CommunityFragment.openCMD;

public class ReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        init();
    }
    private void init() {
        final LinearLayout postlist = findViewById(R.id.postlist);
        final SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.refreshcmd);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                setCommant(ReportActivity.this,postlist,swipeRefreshLayout);
            }
        });
        setCommant(ReportActivity.this,postlist,swipeRefreshLayout);
    }
    public static void setCommant(Activity context, LinearLayout postlist, SwipeRefreshLayout refreshLayout) {
        postlist.removeAllViews();
        refreshLayout.setRefreshing(true);
        HttpAgent.get(MainActivity.getApi("data/user/getReport.php"))
                .setTimeOut(10000)
                .goJsonArray(new JsonArrayCallback() {
                    @Override
                    protected void onDone(boolean success, JSONArray jsonResults) {
                        refreshLayout.setRefreshing(false);
                        if (success) {
                            for (int i = 0; i < jsonResults.length(); i++) {
                                try {
                                    JSONObject fullpost = new JSONObject();
                                    fullpost = jsonResults.getJSONObject(i);
                                    View views = LayoutInflater.from(context).inflate(R.layout.reportlist, null);
                                    final CircleImageView userimage = views.findViewById(R.id.post_image);
                                    final ImageView premium = views.findViewById(R.id.post_premium);
                                    final TextView username = views.findViewById(R.id.post_user);
                                    final TextView time = views.findViewById(R.id.post_time);
                                    final TextView totalcmd = views.findViewById(R.id.totalcmd);
                                    final TextView post = views.findViewById(R.id.post_text);
                                    final ImageButton menu = views.findViewById(R.id.post_menu);
                                    final Button isfire = views.findViewById(R.id.isfire);
                                    final Button showmore = views.findViewById(R.id.showmorebtn);
                                    final ImageButton opencmd = views.findViewById(R.id.opencmd);
                                    final CardView frameLayout = views.findViewById(R.id.blurs);
                                    final LinearLayout anime = views.findViewById(R.id.post_anime);
                                    final LinearLayout giflinear = views.findViewById(R.id.giflinear);
                                    final ImageView gifimage = views.findViewById(R.id.gifimage);
                                    final TextView reporter = views.findViewById(R.id.reporter);
                                    final TextView reportertime = views.findViewById(R.id.reportertime);
                                    final TextView reportermessage = views.findViewById(R.id.reportermessage);
                                    reporter.setText("بلاغ من "+jsonResults.getJSONObject(i).getString("user"));
                                    reportertime.setText(AnimeUtil.getTimeAgo(jsonResults.getJSONObject(i).getString("time")));
                                    reportermessage.setText(jsonResults.getJSONObject(i).getString("message"));
                                    final Boolean[] isShowing = {false};
                                    int finalI1 = i;
                                    int finalI2 = i;

                                    int finalI3 = i;
                                    userimage.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            try {
                                                final LoadingDialog ld = new LoadingDialog(context);
                                                ld.setLoadingText("يرجى الانتظار").show();
                                                HttpAgent.get(MainActivity.getApi("data/user/profile.php/?username="+jsonResults.getJSONObject(finalI3).getJSONObject("post").getString("username")))
                                                        .setTimeOut(10000)
                                                        .goString(new StringCallback() {
                                                            @Override
                                                            protected void onDone(boolean success, String stringResults) {
                                                                if (success) {
                                                                    ld.close();
                                                                    try {
                                                                        JSONObject obj = new JSONObject(stringResults);
                                                                        AccountUtil.openProfile(obj,context);
                                                                    } catch (JSONException e) {
                                                                        e.printStackTrace();
                                                                    }
                                                                } else {
                                                                    ld.close();
                                                                    MainActivity.showMessage(getErrorMessage(),context);
                                                                }
                                                            }
                                                        });
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                    int finalI4 = i;
                                    opencmd.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            try {
                                                openCMD(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("id"),jsonResults.getJSONObject(finalI4).getJSONObject("post").getJSONArray("commant"),context);
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                    if (jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("hasImage").isEmpty()) {
                                        giflinear.setVisibility(View.GONE);
                                    } else {
                                        giflinear.setVisibility(View.VISIBLE);
                                        if (jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("hasImage").contains("gif")) {
                                            Glide.with(context).asGif().load(Uri.parse(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                                        } else {
                                            Glide.with(context).load(Uri.parse(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                                        }
                                    }
                                    totalcmd.setText(String.valueOf(jsonResults.getJSONObject(finalI4).getJSONObject("post").getJSONArray("commant").length()));
                                    showmore.setVisibility(View.GONE);
                                    isfire.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            frameLayout.setVisibility(View.GONE);
                                            post.setVisibility(View.VISIBLE);
                                        }
                                    });
                                    if (jsonResults.getJSONObject(finalI4).getJSONObject("post").getBoolean("hasFire")) {
                                        frameLayout.setVisibility(View.VISIBLE);
                                        post.setVisibility(View.GONE);
                                    } else {
                                        frameLayout.setVisibility(View.GONE);
                                    }
                                    username.setText(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("username"));
                                    if (jsonResults.getJSONObject(finalI4).getJSONObject("post").getBoolean("hasPremium")) {
                                        username.setTextColor(Color.parseColor(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("premium")));
                                        premium.setVisibility(View.VISIBLE);
                                    } else {
                                        username.setTextColor(Color.parseColor("#ffffff"));
                                        premium.setVisibility(View.GONE);
                                    }
                                    time.setText(AnimeUtil.getTimeAgo(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("time")));
                                    int line = getLineCount(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("post"));
                                    if (line > 14) {
                                        showmore.setVisibility(View.VISIBLE);
                                    }
                                    String flpost = jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("post");
                                    showmore.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if (isShowing[0]) {
                                                post.setText(flpost);
                                                isShowing[0] = false;
                                                post.setMaxLines(10);
                                                showmore.setText("قرائة الكل");
                                            } else {
                                                post.setText(flpost+newLine());
                                                isShowing[0] = true;
                                                post.setMaxLines(Integer.MAX_VALUE);
                                                post.setText(post.getText().toString() + "");
                                                showmore.setText("أخفاء");
                                            }
                                        }
                                    });
                                    post.setText(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("post"));
                                    final String postid = jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("id");
                                    Glide.with(context).load(Uri.parse(jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("userimage"))).into(userimage);
                                    int finalI = i;
                                    if (jsonResults.getJSONObject(finalI4).getJSONObject("post").getBoolean("hasAnime")) {
                                        for (int is = 0; is <jsonResults.getJSONObject(finalI4).getJSONObject("post").getJSONArray("anime").length(); is++) {
                                            View viewss = LayoutInflater.from(context).inflate(R.layout.otherlist, null);
                                            final ImageView images = (ImageView) viewss.findViewById(R.id.exampleimg);
                                            final LinearLayout linear2 = (LinearLayout) viewss.findViewById(R.id.linear2);
                                            final ProgressBar loadings = (ProgressBar) viewss.findViewById(R.id.prof);
                                            final TextView textview2 = (TextView) viewss.findViewById(R.id.exampletxt2);
                                            textview2.setText(jsonResults.getJSONObject(finalI4).getJSONObject("post").getJSONArray("anime").getJSONObject(i).getString("name"));
                                            int finalIs = is;
                                            linear2.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    try {
                                                        final LoadingDialog dl = new LoadingDialog(context);
                                                        dl.setLoadingText("يرجى الانتظار");
                                                        dl.show();
                                                        HttpAgent.get(MainActivity.getApi("data/inf.php?id="+jsonResults.getJSONObject(finalI4).getJSONObject("post").getJSONArray("anime").getJSONObject(finalIs).getString("id")))
                                                                .setTimeOut(10000)
                                                                .goString(new StringCallback() {
                                                                    @Override
                                                                    protected void onDone(boolean success, String stringResults) {
                                                                        dl.close();
                                                                        if (success){
                                                                            try {
                                                                                if (imageToBitmap.DDA(stringResults).contains("error make image")) {
                                                                                    MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                                    context.startActivity(new Intent(context, InfoActivity.class));
                                                                                } else {
                                                                                    MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                                    context.startActivity(new Intent(context, InfoActivity.class));
                                                                                }
                                                                            } catch (Exception e) {
                                                                                e.printStackTrace();
                                                                                Toast.makeText(context,"توجد مشكلة أو صيانة في السيرفر يتم العمل عليها حاليا يرجى الانتظار",Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        } else {
                                                                            Toast.makeText(context,"توجد مشكلة في الشبكة تحقق منها وأعد المحاولة",Toast.LENGTH_SHORT).show();
                                                                        }
                                                                    }
                                                                });
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                            });
                                            Glide.with(context)
                                                    .load(Uri.parse(jsonResults.getJSONObject(finalI4).getJSONObject("post").getJSONArray("anime").getJSONObject(i).getString("image")))
                                                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                                                    .listener(new RequestListener<Drawable>() {
                                                        @Override
                                                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                                            return false;
                                                        }
                                                        @Override
                                                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                                            loadings.setVisibility(View.GONE);
                                                            return false;
                                                        }
                                                    })
                                                    .into(images);
                                            viewss.setId(i);
                                            anime.addView(viewss);
                                        }
                                    }
                                    final String users = jsonResults.getJSONObject(finalI4).getJSONObject("post").getString("username");
                                    JSONObject finalFullpost = fullpost;
                                    menu.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            PopupMenu popup = new PopupMenu(context, v);
                                            MenuInflater inflater = popup.getMenuInflater();
                                            inflater.inflate(R.menu.menu_cmd, popup.getMenu());
                                            popup.getMenu().getItem(0).setVisible(true);
                                            popup.getMenu().getItem(1).setVisible(true);
                                            popup.getMenu().getItem(1).setTitle("حذف");
                                            popup.getMenu().getItem(0).setTitle("غير مخالف");
                                            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                @Override
                                                public boolean onMenuItemClick(MenuItem item) {
                                                    if (item.getItemId() == popup.getMenu().getItem(1).getItemId()) {
                                                        final LoadingDialog ld = new LoadingDialog(context);
                                                        ld.setLoadingText("يرجى الانتظار").show();
                                                        HttpAgent.get(getApi("data/user/delete.php/?id="+postid+"&username="+AccountUtil.getUsername(context)+"&password="+AccountUtil.getPassword(context)))
                                                                .setTimeOut(10000)
                                                                .goString(new StringCallback() {
                                                                    @Override
                                                                    protected void onDone(boolean success, String stringResults) {
                                                                        if (success) {
                                                                            ld.close();
                                                                            showMessage("تم حذف المنشور",context);
                                                                        } else {
                                                                            ld.setFailedText(getErrorMessage());
                                                                            ld.loadFailed();
                                                                        }
                                                                    }
                                                                });
                                                    } else {
                                                        final LoadingDialog ld = new LoadingDialog(context);
                                                        ld.setLoadingText("يرجى الانتظار").show();
                                                        HttpAgent.get(getApi("data/user/dontdelete.php/?id="+postid+"&username="+AccountUtil.getUsername(context)+"&password="+AccountUtil.getPassword(context)))
                                                                .setTimeOut(10000)
                                                                .goString(new StringCallback() {
                                                                    @Override
                                                                    protected void onDone(boolean success, String stringResults) {
                                                                        if (success) {
                                                                            ld.close();
                                                                            showMessage("غير مخالف",context);
                                                                        } else {
                                                                            ld.setFailedText(getErrorMessage());
                                                                            ld.loadFailed();
                                                                        }
                                                                    }
                                                                });
                                                    }
                                                    return false;
                                                }
                                            });
                                            popup.show();
                                        }
                                    });
                                    views.setId(i);
                                    postlist.addView(views);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        } else {
                            Toast.makeText(context,getErrorMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

}