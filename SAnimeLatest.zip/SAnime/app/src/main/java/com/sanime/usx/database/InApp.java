package com.sanime.usx.database;

public class InApp {
    String _id;
    String _name;
    String _image;
    public InApp(){   }
    public InApp(String id){
        this._id = id;
    }
    public String getID(){
        return this._id;
    }

    public void setID(String id){
        this._id = id;
    }

}