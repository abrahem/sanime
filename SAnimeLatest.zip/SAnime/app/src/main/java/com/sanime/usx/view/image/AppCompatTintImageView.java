package com.sanime.usx.view.image;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.AttrRes;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.appcompat.widget.AppCompatImageView;
/**
 * Created by max on 2017/12/03.
 */

public class AppCompatTintImageView extends AppCompatImageView {

    public AppCompatTintImageView(Context context) {
        super(context);
    }

    public AppCompatTintImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public AppCompatTintImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * Optionally included when constructing custom views
     */
    public void onInit() {

    }

    /**
     * Clean up any resources that won't be needed
     */
    public void onViewRecycled() {

    }
}
