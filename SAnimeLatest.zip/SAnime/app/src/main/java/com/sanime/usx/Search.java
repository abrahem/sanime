package com.sanime.usx;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.textfield.TextInputEditText;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import static com.sanime.usx.MainActivity.mInterstitialAd;

public class Search extends AppCompatActivity {
    private String url = MainActivity.getApi("data/search.php/?name=");
    private TextInputEditText sear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_anime);
        try {
            getSupportActionBar().hide();
        } catch (Exception e) {

        }
        final ImageButton btn = findViewById(R.id.searchan);
        sear = findViewById(R.id.animeinput);
        sear.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    btn.performClick();
                    return true;
                }
                return false;
            }
        });
        final String[] name = {""};
        ((TextInputEditText) findViewById(R.id.animeinput)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                name[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final LoadingDialog ld = new LoadingDialog(Search.this);
                ld.setLoadingText("يرجى الانتظار").show();
                String q = name[0];
                String urls = null;
                try {
                    urls = url + URLEncoder.encode(q, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                HttpAgent.get(urls)
                        .setTimeOut(10000)
                        .goString(new StringCallback() {
                            @Override
                            protected void onDone(boolean success, String response) {
                                sear.setText("");
                                ld.close();
                                if (success) {
                                    JSONArray ary = null;
                                    if (response.contains("[]")) {
                                        Toast.makeText(Search.this,"لا توجد انميات بهذا الاسم حاول كتابة الاسم بطريقة صحيحة",Toast.LENGTH_SHORT).show();
                                    }
                                    try {
                                        if (mInterstitialAd.isLoaded()) {
                                            mInterstitialAd.show();
                                            mInterstitialAd = new InterstitialAd(getApplicationContext());
                                            mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                            mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                        } else {
                                            Log.d("TAG", "The interstitial wasn't loaded yet.");
                                        }
                                        ary = new JSONArray(response);
                                        GridLayoutManager gridLayoutManager3;
                                        RecyclerView rvContacts3 = findViewById(R.id.rvContacts4);
                                        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                                            gridLayoutManager3 = new GridLayoutManager(getApplicationContext(),2, LinearLayoutManager.VERTICAL,false);
                                        }
                                        else{
                                            gridLayoutManager3 = new GridLayoutManager(getApplicationContext(),4, LinearLayoutManager.VERTICAL,false);
                                        }
                                        rvContacts3.setLayoutManager(gridLayoutManager3); // set LayoutManager to RecyclerView
                                        ArrayList<Anime> contacts3 = new ArrayList<Anime>();
                                        ContactsAdapter adapter3 = new ContactsAdapter(contacts3);
                                        for (int is = 0; is < ary.length(); is++) {
                                            contacts3.add(new Anime(ary.getJSONObject(is).getString("name"),ary.getJSONObject(is).getString("status"),ary.getJSONObject(is).getString("image"),ary.getJSONObject(is).getString("id")));
                                        }
                                        rvContacts3.setAdapter(adapter3);
                                        rvContacts3.getAdapter().notifyDataSetChanged();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                } else {

                                }
                            }
                        });
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
    }
}
