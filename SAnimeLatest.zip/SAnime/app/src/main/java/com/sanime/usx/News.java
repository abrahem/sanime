package com.sanime.usx;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.sanime.usx.ui.slideshow.SlideshowFragment;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import static com.sanime.usx.ui.community.CommunityFragment.newLine;
import static com.sanime.usx.ui.slideshow.SlideshowFragment.CONTENT;
import static com.sanime.usx.ui.slideshow.SlideshowFragment.TIME;
import static com.sanime.usx.ui.slideshow.SlideshowFragment.URLS;

public class News extends AppCompatActivity {
    private TextInputEditText sear;
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news);
        try {
            getSupportActionBar().hide();
        } catch (Exception e) {

        }
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = CONTENT;
                shareBody = shareBody + newLine() + "شاهد الخبر الكامل على الرابط التالي" + newLine() + URLS + newLine() + "تم مشاركة الخبر عن طريق تطبيق SAnime يمكنكم تحميلة عن طريق الرابط التالي " + newLine() + "https://play.google.com/store/apps/details?id=com.sanime.usx";
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "مشاركة عبر"));
            }
        });
        final WebView webView = findViewById(R.id.webview);
        final SwipeRefreshLayout refreshLayout = findViewById(R.id.refresh);
        webView.setBackgroundColor(Color.parseColor("#ff252e39"));
        refreshLayout.setRefreshing(true);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                webView.getSettings().setAllowContentAccess(true);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl(SlideshowFragment.URLS);
                webView.setWebViewClient(new WebViewClient() {
                    public void onPageFinished(WebView view, String url) {
                        refreshLayout.setRefreshing(false);
                    }
                });
            }
        });
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(SlideshowFragment.URLS);
        webView.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                refreshLayout.setRefreshing(false);
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
    }
}
