package com.sanime.usx.adapter;

public class Anime {
    private String name;
    private String title;
    private String image;
    private String id;


    public Anime(String name,String title,String image,String id) {
        this.name = name;
        this.title = title;
        this.image = image;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    public String getId() {
        return id;
    }
}