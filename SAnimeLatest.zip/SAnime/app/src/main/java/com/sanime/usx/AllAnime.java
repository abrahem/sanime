package com.sanime.usx;

import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import static com.sanime.usx.info.InfoActivity.GENEREANIME;
import static com.sanime.usx.info.InfoActivity.GENERENAME;

public class AllAnime extends AppCompatActivity {
    private TextView titles;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.getanime);
        try {
            getSupportActionBar().hide();
        } catch (Exception e) {

        }
        final ImageButton btn = findViewById(R.id.allback);
        titles = findViewById(R.id.alltitle);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        titles.setText(GENERENAME);
        JSONArray ary = null;
        if (GENEREANIME.contains("[]")) {
            Toast.makeText(AllAnime.this,"لا توجد أنميات",Toast.LENGTH_SHORT).show();
        }
        try {
            ary = new JSONArray(GENEREANIME);
            GridLayoutManager gridLayoutManager3;
            RecyclerView rvContacts3 = findViewById(R.id.rvContacts5);
            if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                gridLayoutManager3 = new GridLayoutManager(getApplicationContext(),2, LinearLayoutManager.VERTICAL,false);
            }
            else{
                gridLayoutManager3 = new GridLayoutManager(getApplicationContext(),4, LinearLayoutManager.VERTICAL,false);
            }
            rvContacts3.setLayoutManager(gridLayoutManager3); // set LayoutManager to RecyclerView
            ArrayList<Anime> contacts3 = new ArrayList<Anime>();
            ContactsAdapter adapter3 = new ContactsAdapter(contacts3);
            for (int is = 0; is < ary.length(); is++) {
                View views =  getLayoutInflater().inflate(R.layout.lists, null, false);
                final TextView title = views.findViewById(R.id.series_title);
                final TextView title2 = views.findViewById(R.id.title2);
                final ImageView img = views.findViewById(R.id.series_image);
                title2.setText(ary.getJSONObject(is).getString("status"));
                title.setText(ary.getJSONObject(is).getString("name"));
                Glide.with(getApplicationContext()).load(Uri.parse(ary.getJSONObject(is).getString("image"))).into(img);
                views.setId(is);
                contacts3.add(new Anime(ary.getJSONObject(is).getString("name"),ary.getJSONObject(is).getString("status"),ary.getJSONObject(is).getString("image"),ary.getJSONObject(is).getString("id")));
            }
            rvContacts3.setAdapter(adapter3);
            rvContacts3.getAdapter().notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onResume() {
        super.onResume();
    }
}
