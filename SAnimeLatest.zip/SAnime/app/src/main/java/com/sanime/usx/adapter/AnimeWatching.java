package com.sanime.usx.adapter;

public class AnimeWatching {
    private String name;
    private String title;
    private String image;
    private String id;
    private String animeid;


    public AnimeWatching(String name, String title, String image, String id,String animeid ) {
        this.name = name;
        this.title = title;
        this.image = image;
        this.id = id;
        this.animeid = animeid;
    }
    public String getAnimeid() {
        return animeid;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    public String getId() {
        return id;
    }
}