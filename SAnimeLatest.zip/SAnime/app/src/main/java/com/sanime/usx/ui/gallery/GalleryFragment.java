package com.sanime.usx.ui.gallery;

import android.app.Activity;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.sanime.usx.R;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.AnimeWatching;
import com.sanime.usx.adapter.ContactsAdapter;
import com.sanime.usx.adapter.FavAdapter;
import com.sanime.usx.adapter.WatchingAdapter;
import com.sanime.usx.database.DatabaseHandler;
import com.sanime.usx.database.DatabaseWatching;

import java.util.ArrayList;

import static com.sanime.usx.MainActivity.viewPagerTab2;

public class GalleryFragment extends Fragment {

    private GalleryViewModel galleryViewModel;
    public static DatabaseHandler fav;
    public static DatabaseWatching watch;
    public static FragmentActivity ACTIVITYFAV;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        fav = new DatabaseHandler(getContext());
        watch = new DatabaseWatching(getContext());
        DemoCollectionPagerAdapter demoCollectionPagerAdapter = new DemoCollectionPagerAdapter(getChildFragmentManager());
        ViewPager viewPager = root.findViewById(R.id.viewpager);
        viewPager.setAdapter(demoCollectionPagerAdapter);
        viewPagerTab2.setViewPager(viewPager);
        galleryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                fav = new DatabaseHandler(getContext());
                watch = new DatabaseWatching(getContext());
                DemoCollectionPagerAdapter demoCollectionPagerAdapter = new DemoCollectionPagerAdapter(getChildFragmentManager());
                ViewPager viewPager = root.findViewById(R.id.viewpager);
                viewPager.setAdapter(demoCollectionPagerAdapter);
                viewPagerTab2.setViewPager(viewPager);
            }
        });
        return root;
    }
    public class DemoCollectionPagerAdapter extends FragmentStatePagerAdapter {
        public DemoCollectionPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {
            Fragment fragment = new DemoObjectFragment();
            Bundle args = new Bundle();
            // Our object is just an integer :-P
            args.putInt(DemoObjectFragment.ARG_OBJECT, i + 1);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            CharSequence string = "";
            switch (position) {
                case 0:
                    string = getString(R.string.tab_fav);
                    break;
                case 1:
                    string = getString(R.string.tab_watching);
                    break;
            }
            return string;
        }
    }
    public static class DemoObjectFragment extends Fragment {
        public static final String ARG_OBJECT = "object";

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            Bundle args = getArguments();
            ACTIVITYFAV = getActivity();
            View view;
            switch (args.getInt("object")) {
                case 1:
                    view = inflater.inflate(R.layout.fragment_pager_list, container, false);
                    break;
                case 2:
                    view = inflater.inflate(R.layout.fragment_pager_list2, container, false);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + args.getInt("object"));
            }
            return view;
        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            RecyclerView rvContacts = view.findViewById(R.id.rvContacts);
            RecyclerView rvContacts2 = view.findViewById(R.id.rvContacts2);
            Bundle args = getArguments();
            try {
                switch (args.getInt("object")) {
                    case 1:
                        GridLayoutManager gridLayoutManager;
                        if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                            gridLayoutManager = new GridLayoutManager(getContext(),2, LinearLayoutManager.VERTICAL,false);
                        }
                        else{
                            gridLayoutManager = new GridLayoutManager(getContext(),4, LinearLayoutManager.VERTICAL,false);
                        }
                        rvContacts.setLayoutManager(gridLayoutManager); // set LayoutManager to RecyclerView
                        ArrayList<Anime> contacts = new ArrayList<Anime>();
                        FavAdapter adapter = new FavAdapter(contacts);
                        for (int i = 0; i < fav.getAllFav().size(); i++) {
                            contacts.add(new Anime(fav.getAllFav().get(i).getName(),"",fav.getAllFav().get(i).getImageUrl(),fav.getAllFav().get(i).getID()));
                        }

                        rvContacts.setAdapter(adapter);
                        rvContacts.getAdapter().notifyDataSetChanged();
                        break;
                    case 2:
                        GridLayoutManager gridLayoutManager2;
                        if(getActivity().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                            gridLayoutManager2 = new GridLayoutManager(getContext(),2, LinearLayoutManager.VERTICAL,false);
                        }
                        else{
                            gridLayoutManager2 = new GridLayoutManager(getContext(),4, LinearLayoutManager.VERTICAL,false);
                        }
                        rvContacts2.setLayoutManager(gridLayoutManager2); // set LayoutManager to RecyclerView
                        ArrayList<AnimeWatching> contacts2 = new ArrayList<AnimeWatching>();
                        for (int i = 0; i < watch.getAllWatching().size(); i++) {
                            contacts2.add(new AnimeWatching(watch.getAllWatching().get(i).getName(),"",watch.getAllWatching().get(i).getImageUrl(),watch.getAllWatching().get(i).getID(),watch.getAllWatching().get(i).getAnimeID()));
                        }
                        WatchingAdapter adapter2 = new WatchingAdapter(contacts2);
                        rvContacts2.setAdapter(adapter2);
                        rvContacts2.getAdapter().notifyDataSetChanged();
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}