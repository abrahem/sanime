package com.sanime.usx.adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.database.DatabaseHandler;
import com.sanime.usx.info.InfoActivity;
import com.sanime.usx.view.image.imageToBitmap;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import java.util.List;

import static com.sanime.usx.ui.gallery.GalleryFragment.ACTIVITYFAV;

public class FavAdapter extends RecyclerView.Adapter<FavAdapter.ViewHolder> {
        // ... view holder defined above...

        // Store a member variable for the contacts
        private List<Anime> mContacts;

        // Pass in the contact array into the constructor
        public FavAdapter(List<Anime> Anime) {
            mContacts = Anime;
        }
    public class ViewHolder extends RecyclerView.ViewHolder{
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView nameTextView;
        public TextView messageButton;
        public ImageView img;
        public CardView container;
        public Context context;
        public View items;
        public ViewHolder(Context context, View itemView) {
            super(itemView);
            this.items = itemView;
            this.context = context;
            this.nameTextView = (TextView) itemView.findViewById(R.id.series_title);
            this.messageButton = (TextView) itemView.findViewById(R.id.title2);
            this.container = (CardView) itemView.findViewById(R.id.container);
            this.img = (ImageView) itemView.findViewById(R.id.series_image);
            // Store the context
        }
    }
    @Override
    public FavAdapter.ViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        final Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.lists, parent, false);
        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(context,contactView);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(final FavAdapter.ViewHolder viewHolder, int position) {
        // Get the data model based on position
        final Anime contact = mContacts.get(position);

        // Set item views based on your views and data model
        TextView textView = viewHolder.nameTextView;
        textView.setText(contact.getName());
        TextView button = viewHolder.messageButton;
        CardView vi = viewHolder.container;
        ImageView img = viewHolder.img;
        Glide.with(viewHolder.context).load(Uri.parse(contact.getImage())).into(img);
        button.setText(contact.getTitle());
        vi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialogs = new Dialog(viewHolder.context);
                dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialogs.setContentView(R.layout.menus);
                dialogs.setCancelable(true);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(dialogs.getWindow().getAttributes());
                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                therebtn.setVisibility(View.GONE);
                onebtn.setText("صفحة الانمي");
                onebtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogs.dismiss();
                        final LoadingDialog dl = new LoadingDialog(viewHolder.context);
                        dl.setLoadingText("يرجى الانتظار");
                        dl.show();
                        HttpAgent.get(MainActivity.getApi("data/inf.php?id="+contact.getId()))
                                .setTimeOut(10000)
                                .goString(new StringCallback() {
                                    @Override
                                    protected void onDone(boolean success, String stringResults) {
                                        dl.close();
                                        if (success){
                                            try {
                                                if (imageToBitmap.DDA(stringResults).contains("error make image")) {
                                                    MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                    viewHolder.context.startActivity(new Intent(viewHolder.context, InfoActivity.class));
                                                } else {
                                                    MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                    viewHolder.context.startActivity(new Intent(viewHolder.context, InfoActivity.class));
                                                }
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                Toast.makeText(viewHolder.context,"توجد مشكلة أو صيانة في السيرفر يتم العمل عليها حاليا يرجى الانتظار",Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast.makeText(viewHolder.context,"توجد مشكلة في الشبكة تحقق منها وأعد المحاولة",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    }
                });
                twobtn.setText("حذف من المفضلة");
                twobtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogs.dismiss();
                        DatabaseHandler fav = new DatabaseHandler(viewHolder.context);
                        fav.deleteFav(fav.getFav(contact.getId()));
                        ACTIVITYFAV.recreate();
                    }
                });
                dialogs.show();
                dialogs.getWindow().setAttributes(lp);
                 }
        });
    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return mContacts.size();
    }
}