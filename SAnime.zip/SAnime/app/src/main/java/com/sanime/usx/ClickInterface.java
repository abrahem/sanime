package com.sanime.usx;

public interface ClickInterface
{
    void itemClicked(int position);
}