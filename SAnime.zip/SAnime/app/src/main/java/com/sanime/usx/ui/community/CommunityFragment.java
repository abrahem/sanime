package com.sanime.usx.ui.community;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.textfield.TextInputEditText;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.sanime.usx.AnimeUtil;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.account.AccountUtil;
import com.sanime.usx.info.InfoActivity;
import com.sanime.usx.view.CircleImageView;
import com.sanime.usx.view.image.AspectImageView;
import com.sanime.usx.view.image.imageToBitmap;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonArrayCallback;
import com.studioidan.httpagent.JsonCallback;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import static com.sanime.usx.MainActivity.getApi;
import static com.sanime.usx.MainActivity.isValid;
import static com.sanime.usx.MainActivity.viewPagerTab3;

public class CommunityFragment extends Fragment {
    private CommunityViewModel slideshowViewModel;
    public static String CHATURL = "";
    public static String CHATMESSAGE = "";
    public static Boolean IMAGE = false;
    public static Activity ACTIV;
    public static SwipeRefreshLayout SWIPREFRESH;
    public static LinearLayout LINEARPOST;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(CommunityViewModel.class);
        View root = inflater.inflate(R.layout.fragment_community, container, false);
        DemoCollectionPagerAdapter demoCollectionPagerAdapter = new DemoCollectionPagerAdapter(getChildFragmentManager());
        ViewPager viewPager = root.findViewById(R.id.viewpager);
        viewPager.setAdapter(demoCollectionPagerAdapter);
        viewPagerTab3.setViewPager(viewPager);
        slideshowViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
            }
        });
        return root;
    }
    public class DemoCollectionPagerAdapter extends FragmentStatePagerAdapter {
        public DemoCollectionPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {
            Fragment fragment = new DemoObjectFragment();
            Bundle args = new Bundle();
            // Our object is just an integer :-P
            args.putInt(DemoObjectFragment.ARG_OBJECT, i + 1);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            CharSequence string = "";
            switch (position) {
                case 0:
                    string = "المجتمع";
                    break;
                case 1:
                    string = "الدردشة";
                    break;
            }
            return string;
        }
    }
    public static class DemoObjectFragment extends Fragment {
        public static final String ARG_OBJECT = "object";

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            Bundle args = getArguments();
            View view;
            switch (args.getInt("object")) {
                case 1:
                    view = inflater.inflate(R.layout.comm1, container, false);
                    break;
                case 2:
                    view = inflater.inflate(R.layout.comm2, container, false);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + args.getInt("object"));
            }
            return view;
        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            Bundle args = getArguments();
            try {
                switch (args.getInt("object")) {
                    case 1:
                        final SwipeRefreshLayout refreshLayout = view.findViewById(R.id.refreshcmd);
                        final LinearLayout postlist = view.findViewById(R.id.postlist);
                        setCommant(getActivity(),postlist,refreshLayout,view);
                        LINEARPOST = postlist;
                        ACTIV = getActivity();
                        SWIPREFRESH = refreshLayout;
                        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                            @Override
                            public void onRefresh() {
                                postlist.removeAllViews();
                                setCommant(getActivity(),postlist,refreshLayout,view);
                            }
                        });
                        break;
                    case 2:
                        final TextView chatmessage = view.findViewById(R.id.chatmessage);
                        if (CHATMESSAGE.isEmpty()) {
                            final int[] t = {0};
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (CHATMESSAGE.isEmpty()) {
                                        t[0]++;
                                        chatmessage.setText("Time :"+t[0]);
                                        if(t[0] < 500) {
                                            handler.postDelayed(this, 1000);
                                        }
                                    } else {
                                        chatmessage.setText(CHATMESSAGE);
                                    }
                                }
                            }, 1000);
                        }
                        chatmessage.setText(CHATMESSAGE);
                        final ImageButton gochat = view.findViewById(R.id.gochat);
                        gochat.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String url = CHATURL;
                                Intent i = new Intent(Intent.ACTION_VIEW);
                                i.setData(Uri.parse(url));
                                startActivity(i);
                            }
                        });
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public static void setCommant(Activity context, LinearLayout postlist, SwipeRefreshLayout refreshLayout, View view) {
        postlist.removeAllViews();
        refreshLayout.setRefreshing(true);
        HttpAgent.get(MainActivity.getApi("data/user/getpost.php"))
                .setTimeOut(10000)
                .goJson(new JsonCallback() {
                    @Override
                    protected void onDone(boolean success, JSONObject jsonResultss) {
                        refreshLayout.setRefreshing(false);
                        JSONArray jsonResults = null;
                        try {
                            jsonResults = new JSONArray();
                            if (success) {
                                jsonResults = jsonResultss.getJSONArray("post");
                                if (jsonResultss.getString("type").contains("pin")) {
                                    showPin(jsonResultss.getJSONObject("pin"),context,true);
                                }
                                CHATURL = jsonResultss.getString("chat");
                                CHATMESSAGE = jsonResultss.getString("chatmessage");
                                IMAGE = jsonResultss.getBoolean("image");
                                for (int i = 0; i < jsonResults.length(); i++) {
                                    try {
                                        JSONObject fullpost = new JSONObject();
                                        fullpost = jsonResults.getJSONObject(i);
                                        View views = LayoutInflater.from(context).inflate(R.layout.post_list, null);
                                        final CircleImageView userimage = views.findViewById(R.id.post_image);
                                        final ImageView premium = views.findViewById(R.id.post_premium);
                                        final TextView username = views.findViewById(R.id.post_user);
                                        final TextView time = views.findViewById(R.id.post_time);
                                        final TextView totalcmd = views.findViewById(R.id.totalcmd);
                                        final TextView post = views.findViewById(R.id.post_text);
                                        final ImageButton menu = views.findViewById(R.id.post_menu);
                                        final Button isfire = views.findViewById(R.id.isfire);
                                        final Button showmore = views.findViewById(R.id.showmorebtn);
                                        final ImageButton opencmd = views.findViewById(R.id.opencmd);
                                        final CardView frameLayout = views.findViewById(R.id.blurs);
                                        final LinearLayout anime = views.findViewById(R.id.post_anime);
                                        final LinearLayout giflinear = views.findViewById(R.id.giflinear);
                                        final ImageView gifimage = views.findViewById(R.id.gifimage);
                                        final Boolean[] isShowing = {false};
                                        int finalI1 = i;
                                        int finalI2 = i;
                                        JSONArray finalJsonResults = jsonResults;
                                        userimage.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                try {
                                                    final LoadingDialog ld = new LoadingDialog(context);
                                                    ld.setLoadingText("يرجى الانتظار").show();
                                                    HttpAgent.get(MainActivity.getApi("data/user/profile.php/?username="+ finalJsonResults.getJSONObject(finalI2).getString("username")))
                                                            .setTimeOut(10000)
                                                            .goString(new StringCallback() {
                                                                @Override
                                                                protected void onDone(boolean success, String stringResults) {
                                                                    if (success) {
                                                                        ld.close();
                                                                        try {
                                                                            JSONObject obj = new JSONObject(stringResults);
                                                                            AccountUtil.openProfile(obj,context);
                                                                        } catch (JSONException e) {
                                                                            e.printStackTrace();
                                                                        }
                                                                    } else {
                                                                        ld.close();
                                                                        MainActivity.showMessage(getErrorMessage(),context);
                                                                    }
                                                                }
                                                            });
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        JSONArray finalJsonResults1 = jsonResults;
                                        opencmd.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                try {
                                                    openCMD(finalJsonResults1.getJSONObject(finalI1).getString("id"), finalJsonResults1.getJSONObject(finalI1).getJSONArray("commant"),context);
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        if (jsonResults.getJSONObject(i).getString("hasImage").isEmpty()) {
                                            giflinear.setVisibility(View.GONE);
                                        } else {
                                            giflinear.setVisibility(View.VISIBLE);
                                            if (jsonResults.getJSONObject(i).getString("hasImage").contains("gif")) {
                                                Glide.with(context).asGif().load(Uri.parse(jsonResults.getJSONObject(i).getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                                            } else {
                                                Glide.with(context).load(Uri.parse(jsonResults.getJSONObject(i).getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                                            }
                                        }
                                        totalcmd.setText(String.valueOf(jsonResults.getJSONObject(i).getJSONArray("commant").length()));
                                        showmore.setVisibility(View.GONE);
                                        isfire.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                frameLayout.setVisibility(View.GONE);
                                                post.setVisibility(View.VISIBLE);
                                            }
                                        });
                                        if (jsonResults.getJSONObject(i).getBoolean("hasFire")) {
                                            frameLayout.setVisibility(View.VISIBLE);
                                            post.setVisibility(View.GONE);
                                        } else {
                                            frameLayout.setVisibility(View.GONE);
                                        }
                                        username.setText(jsonResults.getJSONObject(i).getString("username"));
                                        if (jsonResults.getJSONObject(i).getBoolean("hasPremium")) {
                                            username.setTextColor(Color.parseColor(jsonResults.getJSONObject(i).getString("premium")));
                                            premium.setVisibility(View.VISIBLE);
                                        } else {
                                            username.setTextColor(Color.parseColor("#ffffff"));
                                            premium.setVisibility(View.GONE);
                                        }
                                        time.setText(AnimeUtil.getTimeAgo(jsonResults.getJSONObject(i).getString("time")));
                                        int line = getLineCount(jsonResults.getJSONObject(i).getString("post"));
                                        if (line > 14) {
                                            showmore.setVisibility(View.VISIBLE);
                                        }
                                        String flpost = jsonResults.getJSONObject(i).getString("post");
                                        showmore.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                if (isShowing[0]) {
                                                    post.setText(flpost);
                                                    isShowing[0] = false;
                                                    post.setMaxLines(10);
                                                    showmore.setText("قرائة الكل");
                                                } else {
                                                    post.setText(flpost+newLine());
                                                    isShowing[0] = true;
                                                    post.setMaxLines(Integer.MAX_VALUE);
                                                    post.setText(post.getText().toString() + "");
                                                    showmore.setText("أخفاء");
                                                }
                                            }
                                        });
                                        post.setText(jsonResults.getJSONObject(i).getString("post"));
                                        final String postid = jsonResults.getJSONObject(i).getString("id");
                                        Glide.with(context).load(Uri.parse(jsonResults.getJSONObject(i).getString("userimage"))).into(userimage);
                                        int finalI = i;
                                        if (jsonResults.getJSONObject(i).getBoolean("hasAnime")) {
                                            for (int is = 0; is <jsonResults.getJSONObject(i).getJSONArray("anime").length(); is++) {
                                                View viewss = LayoutInflater.from(context).inflate(R.layout.otherlist, null);
                                                final ImageView images = (ImageView) viewss.findViewById(R.id.exampleimg);
                                                final LinearLayout linear2 = (LinearLayout) viewss.findViewById(R.id.linear2);
                                                final ProgressBar loadings = (ProgressBar) viewss.findViewById(R.id.prof);
                                                final TextView textview2 = (TextView) viewss.findViewById(R.id.exampletxt2);
                                                textview2.setText(jsonResults.getJSONObject(i).getJSONArray("anime").getJSONObject(is).getString("name"));
                                                int finalIs = is;
                                                JSONArray finalJsonResults3 = jsonResults;
                                                linear2.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        try {
                                                            final LoadingDialog dl = new LoadingDialog(context);
                                                            dl.setLoadingText("يرجى الانتظار");
                                                            dl.show();
                                                            HttpAgent.get(MainActivity.getApi("data/inf.php?id="+ finalJsonResults3.getJSONObject(finalI).getJSONArray("anime").getJSONObject(finalIs).getString("id")))
                                                                    .setTimeOut(10000)
                                                                    .goString(new StringCallback() {
                                                                        @Override
                                                                        protected void onDone(boolean success, String stringResults) {
                                                                            dl.close();
                                                                            if (success){
                                                                                try {
                                                                                    if (imageToBitmap.DDA(stringResults).contains("error make image")) {
                                                                                        MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                                        context.startActivity(new Intent(context, InfoActivity.class));
                                                                                    } else {
                                                                                        MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                                        context.startActivity(new Intent(context, InfoActivity.class));
                                                                                    }
                                                                                } catch (Exception e) {
                                                                                    e.printStackTrace();
                                                                                    Toast.makeText(context,"توجد مشكلة أو صيانة في السيرفر يتم العمل عليها حاليا يرجى الانتظار",Toast.LENGTH_SHORT).show();
                                                                                }
                                                                            } else {
                                                                                Toast.makeText(context,"توجد مشكلة في الشبكة تحقق منها وأعد المحاولة",Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        }
                                                                    });
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                });
                                                Glide.with(context)
                                                        .load(Uri.parse(jsonResults.getJSONObject(i).getJSONArray("anime").getJSONObject(is).getString("image")))
                                                        .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                                                        .listener(new RequestListener<Drawable>() {
                                                            @Override
                                                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                                                return false;
                                                            }
                                                            @Override
                                                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                                                loadings.setVisibility(View.GONE);
                                                                return false;
                                                            }
                                                        })
                                                        .into(images);
                                                viewss.setId(i);
                                                anime.addView(viewss);
                                            }
                                        }
                                        final String users = jsonResults.getJSONObject(i).getString("username");
                                        JSONObject finalFullpost = fullpost;
                                        JSONArray finalJsonResults2 = jsonResults;
                                        menu.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                PopupMenu popup = new PopupMenu(context, v);
                                                MenuInflater inflater = popup.getMenuInflater();
                                                inflater.inflate(R.menu.menu_cmd, popup.getMenu());
                                                popup.getMenu().getItem(1).setVisible(false);
                                                if (AccountUtil.isLogin(context)) {
                                                    if (AccountUtil.isAdmin(context)) {
                                                        popup.getMenu().getItem(1).setVisible(true);
                                                    } else {
                                                        try {
                                                            if (finalJsonResults2.getJSONObject(finalI).getString("username").contains(AccountUtil.getUsername(context))) {
                                                                String user1 = finalJsonResults2.getJSONObject(finalI).getString("username");
                                                                String user2 = AccountUtil.getUsername(context);
                                                                if (user1.length() == user2.length()) {
                                                                    popup.getMenu().getItem(1).setVisible(true);
                                                                }
                                                            }
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                }
                                                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                    @Override
                                                    public boolean onMenuItemClick(MenuItem item) {
                                                        if (item.getItemId() == popup.getMenu().getItem(1).getItemId()) {
                                                            if (AccountUtil.isAdmin(context)) {
                                                                final LoadingDialog ld = new LoadingDialog(context);
                                                                ld.setLoadingText("يرجى الانتظار").show();
                                                                HttpAgent.get(getApi("data/user/delete.php/?id="+postid+"&username="+AccountUtil.getUsername(context)+"&password="+AccountUtil.getPassword(context)))
                                                                        .setTimeOut(10000)
                                                                        .goString(new StringCallback() {
                                                                            @Override
                                                                            protected void onDone(boolean success, String stringResults) {
                                                                                if (success) {
                                                                                    ld.close();
                                                                                    setCommant(context,postlist,refreshLayout,view);
                                                                                } else {
                                                                                    ld.setFailedText(getErrorMessage());
                                                                                    ld.loadFailed();
                                                                                }
                                                                            }
                                                                        });
                                                            } else {
                                                                try {
                                                                    if (finalJsonResults2.getJSONObject(finalI).getString("username").contains(AccountUtil.getUsername(context))) {
                                                                        String user1 = finalJsonResults2.getJSONObject(finalI).getString("username");
                                                                        String user2 = AccountUtil.getUsername(context);
                                                                        if (user1.length() == user2.length()) {
                                                                            final LoadingDialog ld = new LoadingDialog(context);
                                                                            ld.setLoadingText("يرجى الانتظار").show();
                                                                            HttpAgent.get(getApi("data/user/delete.php/?id="+postid+"&username="+AccountUtil.getUsername(context)+"&password="+AccountUtil.getPassword(context)))
                                                                                    .setTimeOut(10000)
                                                                                    .goString(new StringCallback() {
                                                                                        @Override
                                                                                        protected void onDone(boolean success, String stringResults) {
                                                                                            if (success) {
                                                                                                ld.close();
                                                                                                setCommant(context,postlist,refreshLayout,view);
                                                                                            } else {
                                                                                                ld.setFailedText(getErrorMessage());
                                                                                                ld.loadFailed();
                                                                                            }
                                                                                        }
                                                                                    });
                                                                        }
                                                                    }
                                                                } catch (JSONException e) {
                                                                    e.printStackTrace();
                                                                }
                                                            }
                                                        } else {
                                                            AccountUtil.reportPost(context,String.valueOf(System.currentTimeMillis()),AccountUtil.getUsername(context), finalFullpost.toString(),users);
                                                        }
                                                        return false;
                                                    }
                                                });
                                                popup.show();
                                            }
                                        });
                                        views.setId(i);
                                        postlist.addView(views);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            } else {
                                Toast.makeText(context,getErrorMessage(),Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }
    public static String newLine() {
        return "\n"+"\n"+"\n";
    }
    public static int getLineCount(String text){
        return text.split("[\n|\r]").length;
    }
    public static void showPin(JSONObject obj,Context context,Boolean close) {
        try {
            final Dialog dialog = new Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (close) {
                dialog.setCancelable(true);
            } else {
                dialog.setCancelable(false);
            }
            JSONObject fullpost = new JSONObject();
            fullpost = obj;
            View views = LayoutInflater.from(context).inflate(R.layout.pinpost, null);
            final CircleImageView userimage = views.findViewById(R.id.post_image);
            final ImageView premium = views.findViewById(R.id.post_premium);
            final TextView username = views.findViewById(R.id.post_user);
            final TextView time = views.findViewById(R.id.post_time);
            final TextView totalcmd = views.findViewById(R.id.totalcmd);
            final TextView post = views.findViewById(R.id.post_text);
            final ImageButton menu = views.findViewById(R.id.post_menu);
            final Button isfire = views.findViewById(R.id.isfire);
            final Button showmore = views.findViewById(R.id.showmorebtn);
            final ImageButton opencmd = views.findViewById(R.id.opencmd);
            final CardView frameLayout = views.findViewById(R.id.blurs);
            final LinearLayout anime = views.findViewById(R.id.post_anime);
            final LinearLayout giflinear = views.findViewById(R.id.giflinear);
            final ImageView gifimage = views.findViewById(R.id.gifimage);
            final Boolean[] isShowing = {false};
            if (obj.getString("hasImage").isEmpty()) {
                giflinear.setVisibility(View.GONE);
            } else {
                giflinear.setVisibility(View.VISIBLE);
                if (obj.getString("hasImage").contains("gif")) {
                    Glide.with(context).asGif().load(Uri.parse(obj.getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                } else {
                    Glide.with(context).load(Uri.parse(obj.getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                }
            }
            totalcmd.setText(String.valueOf(obj.getJSONArray("commant").length()));
            showmore.setVisibility(View.GONE);
            isfire.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    frameLayout.setVisibility(View.GONE);
                    post.setVisibility(View.VISIBLE);
                }
            });
            if (obj.getBoolean("hasFire")) {
                frameLayout.setVisibility(View.VISIBLE);
                post.setVisibility(View.GONE);
            } else {
                frameLayout.setVisibility(View.GONE);
            }
            username.setText(obj.getString("username"));
            if (obj.getBoolean("hasPremium")) {
                username.setTextColor(Color.parseColor(obj.getString("premium")));
                premium.setVisibility(View.VISIBLE);
            } else {
                username.setTextColor(Color.parseColor("#ffffff"));
                premium.setVisibility(View.GONE);
            }
            time.setText(AnimeUtil.getTimeAgo(obj.getString("time")));
            String flpost = obj.getString("post");
            showmore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isShowing[0]) {
                        post.setText(flpost);
                        isShowing[0] = false;
                        post.setMaxLines(10);
                        showmore.setText("قرائة الكل");
                    } else {
                        post.setText(flpost+newLine());
                        isShowing[0] = true;
                        post.setMaxLines(Integer.MAX_VALUE);
                        post.setText(post.getText().toString() + "");
                        showmore.setText("أخفاء");
                    }
                }
            });
            post.setText(obj.getString("post"));
            final String postid = obj.getString("id");
            Glide.with(context).load(Uri.parse(obj.getString("userimage"))).into(userimage);
            if (obj.getBoolean("hasAnime")) {
                for (int is = 0; is <obj.getJSONArray("anime").length(); is++) {
                    View viewss = LayoutInflater.from(context).inflate(R.layout.otherlist, null);
                    final ImageView images = (ImageView) viewss.findViewById(R.id.exampleimg);
                    final LinearLayout linear2 = (LinearLayout) viewss.findViewById(R.id.linear2);
                    final ProgressBar loadings = (ProgressBar) viewss.findViewById(R.id.prof);
                    final TextView textview2 = (TextView) viewss.findViewById(R.id.exampletxt2);
                    textview2.setText(obj.getJSONArray("anime").getJSONObject(is).getString("name"));
                    int finalIs = is;
                    linear2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            try {
                                final LoadingDialog dl = new LoadingDialog(context);
                                dl.setLoadingText("يرجى الانتظار");
                                dl.show();
                                HttpAgent.get(MainActivity.getApi("data/inf.php?id="+ obj.getJSONArray("anime").getJSONObject(finalIs).getString("id")))
                                        .setTimeOut(10000)
                                        .goString(new StringCallback() {
                                            @Override
                                            protected void onDone(boolean success, String stringResults) {
                                                dl.close();
                                                if (success){
                                                    try {
                                                        if (imageToBitmap.DDA(stringResults).contains("error make image")) {
                                                            MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                            context.startActivity(new Intent(context, InfoActivity.class));
                                                        } else {
                                                            MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                            context.startActivity(new Intent(context, InfoActivity.class));
                                                        }
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        Toast.makeText(context,"توجد مشكلة أو صيانة في السيرفر يتم العمل عليها حاليا يرجى الانتظار",Toast.LENGTH_SHORT).show();
                                                    }
                                                } else {
                                                    Toast.makeText(context,"توجد مشكلة في الشبكة تحقق منها وأعد المحاولة",Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    Glide.with(context)
                            .load(Uri.parse(obj.getJSONArray("anime").getJSONObject(is).getString("image")))
                            .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                            .listener(new RequestListener<Drawable>() {
                                @Override
                                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                    return false;
                                }
                                @Override
                                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                    loadings.setVisibility(View.GONE);
                                    return false;
                                }
                            })
                            .into(images);
                    viewss.setId(is);
                    anime.addView(viewss);
                }
            }
            menu.setVisibility(View.GONE);
            dialog.setContentView(views);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.show();
            dialog.getWindow().setAttributes(lp);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public static void setDimensions(View view, int width, int height){
        android.view.ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = width;
        params.height = height;
        view.setLayoutParams(params);
    }
    public static void openCMD(String id,JSONArray ary, Context context) throws JSONException {
        final Dialog dialogs = new Dialog(context);
        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogs.setContentView(R.layout.addcmd);
        dialogs.setCancelable(true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialogs.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        final String[] command = {""};
        int iss = 0;
        final ImageButton bt_submit = (ImageButton) dialogs.findViewById(R.id.sendcmd);
        final LinearLayout lists = (LinearLayout) dialogs.findViewById(R.id.cmd);
        for(int is=0; is<ary.length(); is++) {
            View views = LayoutInflater.from(context).inflate(R.layout.cmditem, null);
            final TextView names = views.findViewById(R.id.username);
            final CircleImageView userimage = views.findViewById(R.id.userimage);
            final TextView time = views.findViewById(R.id.time);
            final ImageView premium = views.findViewById(R.id.premium);
            final TextView post = views.findViewById(R.id.post);
            names.setText(ary.getJSONObject(is).getString("username"));
            time.setText(AnimeUtil.getTimeAgo(ary.getJSONObject(is).getString("time")));
            post.setText(ary.getJSONObject(is).getString("post"));
            Glide.with(context).load(Uri.parse(ary.getJSONObject(is).getString("userimage")))
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true)
                    .into(userimage);
            if (Boolean.parseBoolean(ary.getJSONObject(is).getString("hasPremium"))) {
                premium.setVisibility(View.VISIBLE);
                names.setTextColor(Color.parseColor(ary.getJSONObject(is).getString("premium")));
            } else {

            }
            views.setId(is);
            iss = is+1;
            lists.addView(views);
        }
        bt_submit.setEnabled(false);
        ((TextInputEditText) dialogs.findViewById(R.id.cmdtxt)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                command[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        int finalIss = iss;
        bt_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean bln = AccountUtil.isLogin(context);
                if (bln) {
                        final LoadingDialog ld = new LoadingDialog(context);
                        ld.setLoadingText("يرجى الانتظار").show();
                        HttpAgent.post(MainActivity.getApi("data/user/add_cmd.php"))
                                .setTimeOut(10000)
                                .headers("Content-Type", "application/x-www-form-urlencoded")
                                .withBody("username="+AccountUtil.getUsername(context)+"&password="+AccountUtil.getPassword(context)+"&post="+command[0]+"&id="+id+"&time="+System.currentTimeMillis())
                                .goString(new StringCallback() {
                                    @Override
                                    protected void onDone(boolean success, String jsonObject) {
                                        if (success) {
                                            ld.setSuccessText(jsonObject);
                                            ld.loadSuccess();
                                            dialogs.dismiss();
                                            View views = new View(context);
                                            setCommant(ACTIV,LINEARPOST,SWIPREFRESH,views);
                                        } else {
                                            ld.setFailedText("توجد مشكلة في الشبكة حاول مرى أخرى");
                                            ld.loadFailed();
                                        }
                                    }
                                });
                } else {
                    Toast.makeText(context,"يجب عليك أنشاء حساب",Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialogs.show();
        dialogs.getWindow().setAttributes(lp);
    }
}