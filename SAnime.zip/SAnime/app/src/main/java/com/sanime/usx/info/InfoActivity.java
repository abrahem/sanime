package com.sanime.usx.info;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.gigamole.navigationtabstrip.NavigationTabStrip;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.sanime.usx.AllAnime;
import com.sanime.usx.AnimeUtil;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.RequestNetwork;
import com.sanime.usx.RequestNetworkController;
import com.sanime.usx.account.AccountUtil;
import com.sanime.usx.database.DatabaseHandler;
import com.sanime.usx.database.DatabaseWatching;
import com.sanime.usx.database.Favorite;
import com.sanime.usx.database.Watching;
import com.sanime.usx.player.VideoPlayer;
import com.sanime.usx.view.CircleImageView;
import com.sanime.usx.view.image.AspectImageView;
import com.sanime.usx.view.image.imageToBitmap;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

@SuppressWarnings("ALL")
public class InfoActivity extends AppCompatActivity {
    public static String gen = "";
    public static Boolean reverses = false;
    public static String EPSD = "";
    public static String EPHD = "";
    public static String ANIMENAME = "";
    public static String EPNAME = "";
    public static String GENEREANIME = "";
    public static String GENERENAME = "";
    public static DatabaseHandler fav;
    public static DatabaseWatching watch;
    private Menu menu;
    public static InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        NavigationTabStrip viewpagertab = findViewById(R.id.viewpagertab);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        fav = new DatabaseHandler(this);
        CollapsingToolbarLayout toolBarLayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        toolBarLayout.setTitle(getTitle());
        ViewPager viewPager = findViewById(R.id.viewpager2);
        DemoCollectionPagerAdapter demoCollectionPagerAdapter = new DemoCollectionPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(demoCollectionPagerAdapter);
        viewpagertab.setViewPager(viewPager);
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        final String TAG = "AppBarTest";
        final AppBarLayout mAppBarLayout = findViewById(R.id.app_bar);
        mAppBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            private State state;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (verticalOffset == 0) {
                    if (state != State.EXPANDED) {
                        try {
                            mAppBarLayout.findViewById(R.id.toolbar).setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.gradint, null));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    state = State.EXPANDED;
                } else if (Math.abs(verticalOffset) >= appBarLayout.getTotalScrollRange()) {
                    if (state != State.COLLAPSED) {

                    }
                    state = State.COLLAPSED;
                } else {
                    if (state != State.IDLE) {
                        Log.d(TAG,"Idle");
                    }
                    state = State.IDLE;
                }
            }
        });
    }
    private enum State {
        EXPANDED,
        COLLAPSED,
        IDLE
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_info, menu);
        try {
            if (MainActivity.INFOS.isEmpty()) {
                MainActivity.showMessage("توجد مشكلة في الشبكة",getApplicationContext());
                finish();
            }
            final JSONObject object = new JSONObject(MainActivity.INFOS);
            try {
                if (object.getJSONObject("main").getString("animeid").contains(fav.getFav(object.getJSONObject("main").getString("animeid")).getID())){
                    menu.getItem(0).setIcon(ContextCompat.getDrawable(this, R.drawable.fav));
                } else {
                    menu.getItem(0).setIcon(ContextCompat.getDrawable(this, R.drawable.unfav));
                }
            } catch (Exception e) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(this, R.drawable.unfav));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addFav:
                try {
                    final JSONObject object = new JSONObject(MainActivity.INFOS);
                    String id = object.getJSONObject("main").getString("animeid");
                    String cover = object.getJSONObject("main").getString("cover");
                    String name = object.getJSONObject("main").getString("name");
                    try {
                        if (id.contains(fav.getFav(id).getID())){
                            item.setIcon(ContextCompat.getDrawable(this, R.drawable.unfav));
                            fav.deleteFav(fav.getFav(id));
                            Toast.makeText(getApplicationContext(),"تم الحذف من المفضلة",Toast.LENGTH_SHORT).show();
                        } else {
                            item.setIcon(ContextCompat.getDrawable(this, R.drawable.fav));
                            fav.addFav(new Favorite(id,name,cover));
                            Toast.makeText(getApplicationContext(),"تم الاضافة الى المفضلة",Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        item.setIcon(ContextCompat.getDrawable(this, R.drawable.fav));
                        fav.addFav(new Favorite(id,name,cover));
                        Toast.makeText(getApplicationContext(),"تم الاضافة الى المفضلة",Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return true;
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public class DemoCollectionPagerAdapter extends FragmentStatePagerAdapter {
        public DemoCollectionPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {
            Fragment fragment = new DemoObjectFragment();
            Bundle args = new Bundle();
            // Our object is just an integer :-P
            args.putInt(DemoObjectFragment.ARG_OBJECT, i + 1);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            CharSequence string = "";
            switch (position) {
                case 0:
                    string = "المعلومات";
                    break;
                case 1:
                    string = "الحلقات";
                    break;
                case 2:
                    string = "التعليقات";
                    break;
            }
            return string;
        }
    }
    public static class DemoObjectFragment extends Fragment {
        public static final String ARG_OBJECT = "object";

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            Bundle args = getArguments();
            View view;
            switch (args.getInt("object")) {
                case 1:
                    view = inflater.inflate(R.layout.fragmentinfo, container, false);
                    break;
                case 2:
                    view = inflater.inflate(R.layout.fragmentep, container, false);
                    break;
                case 3:
                    view = inflater.inflate(R.layout.fragmentcommant, container, false);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + args.getInt("object"));
            }
            return view;
        }

        @Override
        public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
            Bundle args = getArguments();
            watch = new DatabaseWatching(getContext());
            switch (args.getInt("object")) {
                case 1:
                    final AspectImageView cover = view.findViewById(R.id.cover);
                    final ImageView backgraund = getActivity().findViewById(R.id.backgraund);
                    final TextView name = view.findViewById(R.id.name);
                    final TextView nameen = view.findViewById(R.id.nameen);
                    final TextView namejp = view.findViewById(R.id.namejp);
                    final TextView start = view.findViewById(R.id.start);
                    final TextView story = view.findViewById(R.id.story);
                    final TextView type = view.findViewById(R.id.type);
                    final TextView eptime = view.findViewById(R.id.eptime);
                    final TextView relase = view.findViewById(R.id.relase);
                    final TextView rate = view.findViewById(R.id.rate);
                    final TextView age = view.findViewById(R.id.age);
                    final TextView status = view.findViewById(R.id.status);
                    final GridLayout gridLayout = view.findViewById(R.id.genere);
                    final LinearLayout other = view.findViewById(R.id.slider);
                    final CardView generes = view.findViewById(R.id.generes);
                    final AdView mAdView = view.findViewById(R.id.adView);;
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                    try {
                        final JSONObject object = new JSONObject(MainActivity.INFOS);
                        Glide.with(getContext()).load(Uri.parse(object.getJSONObject("main").getString("cover"))).into(cover);
                        Glide.with(getContext()).load(Uri.parse(object.getJSONObject("main").getString("backgraund"))).into(backgraund);
                        name.setText(object.getJSONObject("main").getString("name"));
                        EPNAME = object.getJSONObject("main").getString("name");
                        nameen.setText("أنكليزي : " + object.getJSONObject("main").getString("en"));
                        namejp.setText("ياباني : " + object.getJSONObject("main").getString("jp"));
                        start.setText("بداية الانمي : " + object.getJSONObject("main").getString("start"));
                        story.setText(Html.fromHtml(object.getJSONObject("main").getString("story")));
                        type.setText("النوع : " + object.getJSONObject("main").getString("type"));
                        eptime.setText("مدة الحلقة : " + object.getJSONObject("main").getString("eptime"));
                        relase.setText("أصدار الانمي : " + object.getJSONObject("main").getString("realease"));
                        rate.setText("تقيم الانمي : " + object.getJSONObject("main").getString("rank"));
                        age.setText("التصنيف العمري : " + object.getJSONObject("main").getString("age"));
                        status.setText("حالة الانمي : " + object.getJSONObject("main").getString("status"));
                        for (int i = 0; i <object.getJSONArray("other").length(); i++) {
                            View views = LayoutInflater.from(getContext()).inflate(R.layout.otherlist, null);
                            final ImageView images = (ImageView) views.findViewById(R.id.exampleimg);
                            final LinearLayout linear2 = (LinearLayout) views.findViewById(R.id.linear2);
                            final ProgressBar loadings = (ProgressBar) views.findViewById(R.id.prof);
                            final TextView textview2 = (TextView) views.findViewById(R.id.exampletxt2);
                            textview2.setText(object.getJSONArray("other").getJSONObject(i).getString("name"));
                            final int finalI = i;
                            final int finalI1 = i;
                            linear2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    try {
                                        final LoadingDialog dl = new LoadingDialog(getContext());
                                        dl.setLoadingText("يرجى الانتظار");
                                        dl.show();
                                        HttpAgent.get(MainActivity.getApi("data/inf.php?id="+object.getJSONArray("other").getJSONObject(finalI1).getString("id")))
                                                .setTimeOut(10000)
                                                .goString(new StringCallback() {
                                                    @Override
                                                    protected void onDone(boolean success, String stringResults) {
                                                        dl.close();
                                                        if (success){
                                                            try {
                                                                if (imageToBitmap.DDA(stringResults).contains("error make image")) {
                                                                    MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                    startActivity(new Intent(getContext(), InfoActivity.class));
                                                                    getActivity().finish();
                                                                } else {
                                                                    MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                    startActivity(new Intent(getContext(), InfoActivity.class));
                                                                    getActivity().finish();
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                                Toast.makeText(getContext(),"توجد مشكلة أو صيانة في السيرفر يتم العمل عليها حاليا يرجى الانتظار",Toast.LENGTH_SHORT).show();
                                                            }
                                                        } else {
                                                            Toast.makeText(getContext(),"توجد مشكلة في الشبكة تحقق منها وأعد المحاولة",Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                            Glide.with(getContext())
                                    .load(Uri.parse(object.getJSONArray("other").getJSONObject(i).getString("image")))
                                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                                    .listener(new RequestListener<Drawable>() {
                                        @Override
                                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                            return false;
                                        }
                                        @Override
                                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                            loadings.setVisibility(View.GONE);
                                            return false;
                                        }
                                    })
                                    .into(images);
                            views.setId(i);
                            other.addView(views);
                        }
                        final String animeid = object.getJSONObject("main").getString("animeid");
                        if (object.getJSONObject("main").getBoolean("out")) {
                            HttpAgent.get("https://myanimelist.net/includes/ajax.inc.php?t=64&id="+object.getJSONObject("main").getString("malid"))
                                    .setTimeOut(10000)
                                    .goString(new StringCallback() {
                                        @Override
                                        protected void onDone(boolean success, String stringResults) {
                                            if (success) {
                                                try {
                                                    if (!object.getJSONObject("main").getString("malid").contains("-2")) {
                                                        String hh = stringResults.substring(stringResults.indexOf("<span class=\"dark_text\">Genres:</span>"),stringResults.indexOf("<br"));
                                                        HttpAgent.get(MainActivity.getApi("data/getG.php?id=")+animeid+"&data="+hh.replace("<span class=\"dark_text\">Genres:</span>",""))
                                                                .setTimeOut(10000)
                                                                .goString(new StringCallback() {
                                                                    @Override
                                                                    protected void onDone(boolean success, String stringResults) {
                                                                        try {
                                                                            try {
                                                                                final JSONArray array = new JSONArray(stringResults);
                                                                                try {
                                                                                    generes.setVisibility(View.VISIBLE);
                                                                                    for (int i = 0; i <array.length(); i++) {
                                                                                        View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_tag, null);
                                                                                        final CardView card = views.findViewById(R.id.container);
                                                                                        final TextView name = views.findViewById(R.id.namegn);
                                                                                        String names = array.getJSONObject(i).getString("name").substring(array.getJSONObject(i).getString("name").indexOf("</ID>")).replace("</ID>","");
                                                                                        name.setText(names);
                                                                                        final int finalI = i;
                                                                                        card.setOnClickListener(new View.OnClickListener() {
                                                                                            @Override
                                                                                            public void onClick(View v) {
                                                                                                try {
                                                                                                    LoadingDialog ld = new LoadingDialog(getContext());
                                                                                                    ld.setLoadingText("يرجى الانتظار");
                                                                                                    ld.show();
                                                                                                    String ful = array.getJSONObject(finalI).getString("name").substring(array.getJSONObject(finalI).getString("name").indexOf("</ID>")).replace("</ID>","");
                                                                                                    String id = array.getJSONObject(finalI).getString("name").replace("<ID>","").replace("</ID>","").replace(ful,"");
                                                                                                    HttpAgent.get(MainActivity.getApi("data/genre.php/?name="+id))
                                                                                                            .setTimeOut(10000)
                                                                                                            .goString(new StringCallback() {
                                                                                                                @Override
                                                                                                                protected void onDone(boolean success, String stringResults) {
                                                                                                                    ld.close();
                                                                                                                    if (success) {
                                                                                                                        GENEREANIME = stringResults;
                                                                                                                        GENERENAME = names;
                                                                                                                        startActivity(new Intent(getContext(), AllAnime.class));
                                                                                                                        getActivity().finish();
                                                                                                                    } else {
                                                                                                                        Toast.makeText(getContext(),getErrorMessage(),Toast.LENGTH_SHORT).show();
                                                                                                                    }
                                                                                                                }
                                                                                                            });
                                                                                                } catch (JSONException e) {
                                                                                                    e.printStackTrace();
                                                                                                }
                                                                                            }
                                                                                        });
                                                                                        views.setId(i);
                                                                                        gridLayout.addView(views);
                                                                                    }
                                                                                } catch (Exception E) {
                                                                                    E.printStackTrace();
                                                                                }
                                                                            } catch (NullPointerException ep) {
                                                                                ep.printStackTrace();
                                                                            }
                                                                        } catch (JSONException e) {
                                                                            e.printStackTrace();
                                                                        }
                                                                    }
                                                                });
                                                    }
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            } else {

                                            }
                                        }
                                    });
                        } else {
                            try {
                                generes.setVisibility(View.VISIBLE);
                                for (int i = 0; i <object.getJSONObject("main").getJSONArray("genres").length(); i++) {
                                    View viewss = LayoutInflater.from(getContext()).inflate(R.layout.adapter_tag, null);
                                    final CardView cards = viewss.findViewById(R.id.container);
                                    final TextView names = viewss.findViewById(R.id.namegn);
                                    String namess = object.getJSONObject("main").getJSONArray("genres").getJSONObject(i).getString("name").substring(object.getJSONObject("main").getJSONArray("genres").getJSONObject(i).getString("name").indexOf("</ID>")).replace("</ID>","");
                                    GENERENAME = namess;
                                    names.setText(namess);
                                    final int finalI = i;
                                    final int finalI1 = i;
                                    cards.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            try {
                                                LoadingDialog ld = new LoadingDialog(getContext());
                                                ld.setLoadingText("يرجى الانتظار");
                                                String ful = object.getJSONObject("main").getJSONArray("genres").getJSONObject(finalI1).getString("name").substring(object.getJSONObject("main").getJSONArray("genres").getJSONObject(finalI1).getString("name").indexOf("</ID>")).replace("</ID>","");
                                                String id = object.getJSONObject("main").getJSONArray("genres").getJSONObject(finalI1).getString("name").replace("<ID>","").replace("</ID>","").replace(ful,"");
                                                HttpAgent.get(MainActivity.getApi("data/genre.php/?name="+id))
                                                        .setTimeOut(10000)
                                                        .goString(new StringCallback() {
                                                            @Override
                                                            protected void onDone(boolean success, String stringResults) {
                                                                ld.close();
                                                                if (success) {
                                                                    GENEREANIME = stringResults;
                                                                    startActivity(new Intent(getContext(), AllAnime.class));
                                                                    getActivity().finish();
                                                                } else {
                                                                    Toast.makeText(getContext(),getErrorMessage(),Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                    viewss.setId(i);
                                    gridLayout.addView(viewss);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case 2:
                    final ImageButton reverse = view.findViewById(R.id.reverseanime);
                    final LinearLayout epsoide = view.findViewById(R.id.epsoide);
                    final TextInputEditText searchanime = view.findViewById(R.id.animesearch);
                    searchanime.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            try {
                                epsoide.removeAllViews();
                                final JSONObject object = new JSONObject(MainActivity.INFOS);
                                for (int i = 0; i < object.getJSONArray("ep").length(); i++) {
                                    if (object.getJSONArray("ep").getJSONObject(i).getString("name").contains(s.toString())) {
                                        View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ep, null);
                                        final TextView names = views.findViewById(R.id.nameep);
                                        names.setText(object.getJSONArray("ep").getJSONObject(i).getString("name"));
                                        int finalI = i;
                                        final CardView cardview = views.findViewById(R.id.container);
                                        final ImageView wa = views.findViewById(R.id.watching);
                                        try {
                                            if (object.getJSONArray("ep").getJSONObject(i).getString("id").contains(watch.getWatcing(object.getJSONArray("ep").getJSONObject(i).getString("id")).getID())){
                                                wa.setVisibility(View.VISIBLE);
                                            } else {
                                                wa.setVisibility(View.GONE);
                                            }
                                        } catch (Exception e) {
                                            wa.setVisibility(View.GONE);
                                        }
                                        int finalI1 = i;
                                        JSONObject finalObj = object;
                                        cardview.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                try {
                                                    final JSONObject objects = new JSONObject(MainActivity.INFOS);
                                                    String id = objects.getJSONObject("main").getString("animeid");
                                                    String images = objects.getJSONObject("main").getString("cover");
                                                    String name = objects.getJSONObject("main").getString("name");
                                                    name = name + " : " +finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("name");
                                                    try {
                                                        if (finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id").contains(watch.getWatcing(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id")).getID())){

                                                        } else {
                                                            wa.setVisibility(View.VISIBLE);
                                                            watch.addWatching(new Watching(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id"),name,images,id));
                                                        }
                                                    } catch (Exception e) {
                                                        watch.addWatching(new Watching(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id"),name,images,id));
                                                        wa.setVisibility(View.VISIBLE);
                                                    }
                                                    starts(getContext(),object.getJSONArray("ep").getJSONObject(finalI).getString("id"),EPNAME+"  "+object.getJSONArray("ep").getJSONObject(finalI).getString("name"));
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        views.setId(i);
                                        epsoide.addView(views);
                                    }
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {

                        }
                    });
                    try {
                        final JSONObject object = new JSONObject(MainActivity.INFOS);
                        for (int i = 0; i < object.getJSONArray("ep").length(); i++) {
                            View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ep, null);
                            final TextView names = views.findViewById(R.id.nameep);
                            final ImageView wa = views.findViewById(R.id.watching);
                            names.setText(object.getJSONArray("ep").getJSONObject(i).getString("name"));
                            int finalI = i;
                            final CardView cardview = views.findViewById(R.id.container);
                            int finalI1 = i;
                            try {
                                if (object.getJSONArray("ep").getJSONObject(i).getString("id").contains(watch.getWatcing(object.getJSONArray("ep").getJSONObject(i).getString("id")).getID())){
                                    wa.setVisibility(View.VISIBLE);
                                } else {
                                    wa.setVisibility(View.GONE);
                                }
                            } catch (Exception e) {
                                wa.setVisibility(View.GONE);
                            }
                            JSONObject finalObj = object;
                            cardview.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    try {
                                        final JSONObject objects = new JSONObject(MainActivity.INFOS);
                                        String id = objects.getJSONObject("main").getString("animeid");
                                        String images = objects.getJSONObject("main").getString("cover");
                                        String name = objects.getJSONObject("main").getString("name");
                                        name = name + " : " +finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("name");
                                        try {
                                            if (finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id").contains(watch.getWatcing(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id")).getID())){

                                            } else {
                                                wa.setVisibility(View.VISIBLE);
                                                watch.addWatching(new Watching(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id"),name,images,id));
                                            }
                                        } catch (Exception e) {
                                            watch.addWatching(new Watching(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id"),name,images,id));
                                            wa.setVisibility(View.VISIBLE);
                                        }
                                        starts(getContext(),object.getJSONArray("ep").getJSONObject(finalI).getString("id"),EPNAME+"  "+object.getJSONArray("ep").getJSONObject(finalI).getString("name"));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                            views.setId(i);
                            epsoide.addView(views);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    reverse.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (reverses) {
                                try {
                                    reverses = false;
                                    epsoide.removeAllViews();
                                    final JSONObject object = new JSONObject(MainActivity.INFOS);
                                    for (int i = 0; i < object.getJSONArray("ep").length(); i++) {
                                        View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ep, null);
                                        final TextView names = views.findViewById(R.id.nameep);
                                        final ImageView wa = views.findViewById(R.id.watching);
                                        names.setText(object.getJSONArray("ep").getJSONObject(i).getString("name"));
                                        int finalI = i;
                                        final CardView cardview = views.findViewById(R.id.container);
                                        int finalI1 = i;
                                        try {
                                            if (object.getJSONArray("ep").getJSONObject(i).getString("id").contains(watch.getWatcing(object.getJSONArray("ep").getJSONObject(i).getString("id")).getID())){
                                                wa.setVisibility(View.VISIBLE);
                                            } else {
                                                wa.setVisibility(View.GONE);
                                            }
                                        } catch (Exception e) {
                                            wa.setVisibility(View.GONE);
                                        }
                                        JSONObject finalObj = object;
                                        cardview.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                try {
                                                    final JSONObject objects = new JSONObject(MainActivity.INFOS);
                                                    String id = objects.getJSONObject("main").getString("animeid");
                                                    String images = objects.getJSONObject("main").getString("cover");
                                                    String name = objects.getJSONObject("main").getString("name");
                                                    name = name + " : " +finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("name");
                                                    try {
                                                        if (finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id").contains(watch.getWatcing(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id")).getID())){

                                                        } else {
                                                            wa.setVisibility(View.VISIBLE);
                                                            watch.addWatching(new Watching(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id"),name,images,id));
                                                        }
                                                    } catch (Exception e) {
                                                        watch.addWatching(new Watching(finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("id"),name,images,id));
                                                        wa.setVisibility(View.VISIBLE);
                                                    }
                                                    starts(getContext(),object.getJSONArray("ep").getJSONObject(finalI).getString("id"),EPNAME+"  "+object.getJSONArray("ep").getJSONObject(finalI).getString("name"));
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        views.setId(i);
                                        epsoide.addView(views);
                                    }
                                } catch (JSONException es) {
                                    es.printStackTrace();
                                }
                            } else {
                                try {
                                    reverses = true;
                                    epsoide.removeAllViews();
                                    final JSONObject object = new JSONObject(MainActivity.INFOS);
                                    for (int i = object.getJSONArray("ep").length()-1; i> -1; i--) {
                                        View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ep, null);
                                        final TextView names = views.findViewById(R.id.nameep);
                                        final ImageView wa = views.findViewById(R.id.watching);
                                        names.setText(object.getJSONArray("ep").getJSONObject(i).getString("name"));
                                        int finalI = i;
                                        final CardView cardview = views.findViewById(R.id.container);
                                        int finalI1 = i;
                                        try {
                                            if (object.getJSONArray("ep").getJSONObject(i).getString("id").contains(watch.getWatcing(object.getJSONArray("ep").getJSONObject(i).getString("id")).getID())){
                                                wa.setVisibility(View.VISIBLE);
                                            } else {
                                                wa.setVisibility(View.GONE);
                                            }
                                        } catch (Exception e) {
                                            wa.setVisibility(View.GONE);
                                        }
                                        JSONObject finalObj = object;
                                        cardview.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                try {
                                                    final JSONObject objects = new JSONObject(MainActivity.INFOS);
                                                    String id = objects.getJSONObject("main").getString("animeid");
                                                    String images = objects.getJSONObject("main").getString("cover");
                                                    String name = objects.getJSONObject("main").getString("name");
                                                    name = name + " : " +finalObj.getJSONArray("ep").getJSONObject(finalI1).getString("name");
                                                    starts(getContext(),object.getJSONArray("ep").getJSONObject(finalI).getString("id"),EPNAME+"  "+object.getJSONArray("ep").getJSONObject(finalI).getString("name"));
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        views.setId(i);
                                        epsoide.addView(views);
                                    }
                                } catch (JSONException es) {
                                    es.printStackTrace();
                                }
                            }
                        }
                    });
                    break;
                case 3:
                    final LinearLayout commant = view.findViewById(R.id.commantlist);
                    final TextInputEditText animecommant = view.findViewById(R.id.animecommant);
                    final ImageButton addcommant = view.findViewById(R.id.addcommant);
                    addcommant.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (AccountUtil.isLogin(getContext())) {
                                if (animecommant.getText().toString().isEmpty()) {
                                    Toast.makeText(getContext(),"يرجى كتابة التعليق",Toast.LENGTH_SHORT).show();
                                } else {
                                    final LoadingDialog ld = new LoadingDialog(getContext());
                                    ld.setLoadingText("يرجى الانتظار").show();
                                    RequestNetwork reques2;
                                    RequestNetwork.RequestListener _request2;
                                    reques2 = new RequestNetwork(getActivity());
                                    final JSONObject object;
                                    String animeid = "";
                                    try {
                                        object = new JSONObject(MainActivity.INFOS);
                                        animeid = object.getJSONObject("main").getString("animeid");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    _request2 = new RequestNetwork.RequestListener() {
                                        @Override
                                        public void onResponse(String tag, String response) {
                                            JSONObject obj = null;
                                            try {
                                                obj = new JSONObject(response);
                                                if (obj.getInt("code") == 1) {
                                                    ld.setSuccessText(obj.getString("status"));
                                                    ld.loadSuccess();
                                                    animecommant.setText("");
                                                    try {
                                                        final JSONObject object = new JSONObject(response);
                                                        if (object.getJSONArray("commants").length() != 0) {
                                                            try {
                                                                commant.removeAllViews();
                                                                for (int i = 0; i < object.getJSONArray("commants").length(); i++) {
                                                                    View views = LayoutInflater.from(getContext()).inflate(R.layout.cmditem, null);
                                                                    final TextView names = views.findViewById(R.id.username);
                                                                    final LinearLayout clickcmd = views.findViewById(R.id.clickcmd);
                                                                    final CircleImageView userimage = views.findViewById(R.id.userimage);
                                                                    final TextView time = views.findViewById(R.id.time);
                                                                    final ImageView premium = views.findViewById(R.id.premium);
                                                                    final TextView post = views.findViewById(R.id.post);
                                                                    int finalI = i;
                                                                    userimage.setOnClickListener(new View.OnClickListener() {
                                                                        @Override
                                                                        public void onClick(View view) {
                                                                            final LoadingDialog ld = new LoadingDialog(getActivity());
                                                                            ld.setLoadingText("يرجى الانتظار").show();
                                                                            try {
                                                                                HttpAgent.get(MainActivity.getApi("data/user/profile.php/?username="+ object.getJSONArray("commants").getJSONObject(finalI).getString("name")))
                                                                                        .setTimeOut(10000)
                                                                                        .goString(new StringCallback() {
                                                                                            @Override
                                                                                            protected void onDone(boolean success, String stringResults) {
                                                                                                if (success) {
                                                                                                    ld.close();
                                                                                                    try {
                                                                                                        JSONObject obj = new JSONObject(stringResults);
                                                                                                        AccountUtil.openProfile(obj,getActivity());
                                                                                                    } catch (JSONException e) {
                                                                                                        e.printStackTrace();
                                                                                                    }
                                                                                                } else {
                                                                                                    ld.close();
                                                                                                    MainActivity.showMessage(getErrorMessage(),getActivity());
                                                                                                }
                                                                                            }
                                                                                        });
                                                                            } catch (JSONException e) {
                                                                                e.printStackTrace();
                                                                            }
                                                                        }
                                                                    });
                                                                    names.setText(object.getJSONArray("commants").getJSONObject(i).getString("name"));
                                                                    time.setText(AnimeUtil.getTimeAgo(object.getJSONArray("commants").getJSONObject(i).getString("time")));
                                                                    post.setText(object.getJSONArray("commants").getJSONObject(i).getString("commants"));
                                                                    Glide.with(getContext()).load(Uri.parse(object.getJSONArray("commants").getJSONObject(i).getString("cover"))).into(userimage);
                                                                    if (object.getJSONArray("commants").getJSONObject(i).getBoolean("hasPremium")) {
                                                                        premium.setVisibility(View.VISIBLE);
                                                                        names.setTextColor(Color.parseColor(object.getJSONArray("commants").getJSONObject(i).getString("premium")));
                                                                    } else {

                                                                    }
                                                                    views.setId(i);
                                                                    commant.addView(views);
                                                                }
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }
                                                } else {
                                                    ld.setFailedText(response);
                                                    ld.loadFailed();
                                                    animecommant.setText("");
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }

                                        @Override
                                        public void onErrorResponse(String tag, String message) {
                                            ld.setFailedText("توجد مشكلة في الشبكة حاول مرى أخرى");
                                            ld.loadFailed();
                                            animecommant.setText("");
                                        }
                                    };
                                    reques2.startRequestNetwork(RequestNetworkController.GET,MainActivity.getApi("data/addcmd.php/?id="+animeid+"&name="+AccountUtil.getUsername(getContext())+"&commants="+animecommant.getText().toString()+"&time="+System.currentTimeMillis()+"&password="+AccountUtil.getPassword(getContext())),"",_request2);
                                }
                            } else {
                                MainActivity.showMessage("يجب عليك أنشاء حساب للتعليق",getContext());
                            }
                        }
                    });
                    try {
                        final JSONObject object = new JSONObject(MainActivity.INFOS);
                        if (object.getJSONArray("commants").length() != 0) {
                            try {
                                commant.removeAllViews();
                                for (int i = 0; i < object.getJSONArray("commants").length(); i++) {
                                    View views = LayoutInflater.from(getContext()).inflate(R.layout.cmditem, null);
                                    final TextView names = views.findViewById(R.id.username);
                                    final CircleImageView userimage = views.findViewById(R.id.userimage);
                                    final TextView time = views.findViewById(R.id.time);
                                    final ImageView premium = views.findViewById(R.id.premium);
                                    final TextView post = views.findViewById(R.id.post);
                                    int finalI = i;
                                    userimage.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            final LoadingDialog ld = new LoadingDialog(getActivity());
                                            ld.setLoadingText("يرجى الانتظار").show();
                                            try {
                                                HttpAgent.get(MainActivity.getApi("data/user/profile.php/?username="+ object.getJSONArray("commants").getJSONObject(finalI).getString("name")))
                                                        .setTimeOut(10000)
                                                        .goString(new StringCallback() {
                                                            @Override
                                                            protected void onDone(boolean success, String stringResults) {
                                                                if (success) {
                                                                    ld.close();
                                                                    try {
                                                                        JSONObject obj = new JSONObject(stringResults);
                                                                        AccountUtil.openProfile(obj,getActivity());
                                                                    } catch (JSONException e) {
                                                                        e.printStackTrace();
                                                                    }
                                                                } else {
                                                                    ld.close();
                                                                    MainActivity.showMessage(getErrorMessage(),getActivity());
                                                                }
                                                            }
                                                        });
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                    names.setText(object.getJSONArray("commants").getJSONObject(i).getString("name"));
                                    time.setText(AnimeUtil.getTimeAgo(object.getJSONArray("commants").getJSONObject(i).getString("time")));
                                    post.setText(object.getJSONArray("commants").getJSONObject(i).getString("commants"));
                                    Glide.with(getContext()).load(Uri.parse(object.getJSONArray("commants").getJSONObject(i).getString("cover"))).into(userimage);
                                    if (object.getJSONArray("commants").getJSONObject(i).getBoolean("hasPremium")) {
                                        premium.setVisibility(View.VISIBLE);
                                        names.setTextColor(Color.parseColor(object.getJSONArray("commants").getJSONObject(i).getString("premium")));
                                    } else {

                                    }
                                    views.setId(i);
                                    commant.addView(views);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }
    protected static void starts(final Context context, String id, String nameeps) {
        ANIMENAME = nameeps;
        final LoadingDialog dl = new LoadingDialog(context);
        dl.setLoadingText("يرجى الانتظار").show();
        HttpAgent.get(MainActivity.getApi("data/getEP.php/?id="+id))
                .setTimeOut(10000)
                .goString(new StringCallback() {
                    @Override
                    protected void onDone(boolean success, final String data) {
                        if (success) {
                            dl.close();
                            JSONObject ary = null;
                            try {
                                ary = new JSONObject(imageToBitmap.DDA(data));
                                final Dialog dialogs = new Dialog(context);
                                dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialogs.setContentView(R.layout.menus);
                                dialogs.setCancelable(true);
                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                lp.copyFrom(dialogs.getWindow().getAttributes());
                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                                final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                                final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                                onebtn.setText("تشغيل");
                                onebtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialogs.dismiss();
                                        JSONObject ary = null;
                                        try {
                                            ary = new JSONObject(imageToBitmap.DDA(data));
                                            final Dialog dialogs = new Dialog(context);
                                            dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                            dialogs.setContentView(R.layout.menus);
                                            dialogs.setCancelable(true);
                                            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                            lp.copyFrom(dialogs.getWindow().getAttributes());
                                            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                            final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                                            final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                                            final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                                            therebtn.setVisibility(View.GONE);
                                            onebtn.setText("الدقة الضعيفة");
                                            onebtn.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    if (mInterstitialAd.isLoaded()) {
                                                        mInterstitialAd.show();
                                                        mInterstitialAd = new InterstitialAd(context);
                                                        mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                        mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                                    } else {
                                                        Log.d("TAG", "The interstitial wasn't loaded yet.");
                                                    }
                                                    dialogs.dismiss();
                                                    JSONObject ary = null;
                                                    try {
                                                        ary = new JSONObject(imageToBitmap.DDA(data));
                                                        EPSD = ary.getString("sd");
                                                        EPHD = ary.getString("hd");
                                                        Intent mIntent = VideoPlayer.getStartIntent(context, ary.getString("sd"));
                                                        context.startActivity(mIntent);
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                            });
                                            twobtn.setText("الدقة العالية");
                                            twobtn.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    if (mInterstitialAd.isLoaded()) {
                                                        mInterstitialAd.show();
                                                        mInterstitialAd = new InterstitialAd(context);
                                                        mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                        mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                                    } else {
                                                        Log.d("TAG", "The interstitial wasn't loaded yet.");
                                                    }
                                                    dialogs.dismiss();
                                                    JSONObject ary = null;
                                                    try {
                                                        ary = new JSONObject(imageToBitmap.DDA(data));
                                                        EPSD = ary.getString("sd");
                                                        EPHD = ary.getString("hd");
                                                        Intent mIntent = VideoPlayer.getStartIntent(context, ary.getString("hd"));
                                                        context.startActivity(mIntent);
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                            });
                                            dialogs.show();
                                            dialogs.getWindow().setAttributes(lp);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                                twobtn.setText("تحميل");
                                twobtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialogs.dismiss();
                                        final Dialog dialogs = new Dialog(context);
                                        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        dialogs.setContentView(R.layout.menus);
                                        dialogs.setCancelable(true);
                                        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                        lp.copyFrom(dialogs.getWindow().getAttributes());
                                        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                        final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                                        final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                                        final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                                        therebtn.setVisibility(View.GONE);
                                        onebtn.setText("الدقة الضعيفة");
                                        onebtn.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                dialogs.dismiss();
                                                final Dialog dialogs = new Dialog(context);
                                                dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                                dialogs.setContentView(R.layout.menus);
                                                dialogs.setCancelable(true);
                                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                lp.copyFrom(dialogs.getWindow().getAttributes());
                                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                                                final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                                                final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                                                therebtn.setVisibility(View.GONE);
                                                onebtn.setText("تطبيق خارجي");
                                                onebtn.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        if (mInterstitialAd.isLoaded()) {
                                                            mInterstitialAd.show();
                                                            mInterstitialAd = new InterstitialAd(context);
                                                            mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                            mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                                        } else {
                                                            Log.d("TAG", "The interstitial wasn't loaded yet.");
                                                        }
                                                        dialogs.dismiss();
                                                        JSONObject ary = null;
                                                        try {
                                                            ary = new JSONObject(imageToBitmap.DDA(data));
                                                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                                                            shareIntent.setType("text/plain");
                                                            shareIntent.putExtra("title", ANIMENAME + " الدقة الضعيفة ");
                                                            shareIntent.putExtra(Intent.EXTRA_TEXT, ary.getString("sd"));
                                                            context.startActivity(Intent.createChooser(shareIntent, "اختر طريقة التحميل"));
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                });
                                                twobtn.setText("تطبيق أس انمي");
                                                twobtn.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        dialogs.dismiss();
                                                        JSONObject ary = null;
                                                        try {
                                                            ary = new JSONObject(imageToBitmap.DDA(data));
                                                            Download(ary.getString("sd"), ANIMENAME + " الدقة الضعيفة ",context);
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                });
                                                dialogs.show();
                                                dialogs.getWindow().setAttributes(lp);
                                            }
                                        });
                                        twobtn.setText("الدقة العالية");
                                        twobtn.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                dialogs.dismiss();
                                                final Dialog dialogs = new Dialog(context);
                                                dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                                dialogs.setContentView(R.layout.menus);
                                                dialogs.setCancelable(true);
                                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                lp.copyFrom(dialogs.getWindow().getAttributes());
                                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                                                final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                                                final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                                                therebtn.setVisibility(View.GONE);
                                                onebtn.setText("تطبيق خارجي");
                                                onebtn.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        if (mInterstitialAd.isLoaded()) {
                                                            mInterstitialAd.show();
                                                            mInterstitialAd = new InterstitialAd(context);
                                                            mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                            mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                                        } else {
                                                            Log.d("TAG", "The interstitial wasn't loaded yet.");
                                                        }
                                                        dialogs.dismiss();
                                                        JSONObject ary = null;
                                                        try {
                                                            ary = new JSONObject(imageToBitmap.DDA(data));
                                                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                                                            shareIntent.setType("text/plain");
                                                            shareIntent.putExtra("title", ANIMENAME + " الدقة العالية ");
                                                            shareIntent.putExtra(Intent.EXTRA_TEXT, ary.getString("hd"));
                                                            context.startActivity(Intent.createChooser(shareIntent, "اختر طريقة التحميل"));
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                });
                                                twobtn.setText("تطبيق أس انمي");
                                                twobtn.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        dialogs.dismiss();
                                                        JSONObject ary = null;
                                                        try {
                                                            ary = new JSONObject(imageToBitmap.DDA(data));
                                                            Download(ary.getString("hd"), ANIMENAME + " الدقة العالية ",context);
                                                        } catch (JSONException e) {
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                });
                                                dialogs.show();
                                                dialogs.getWindow().setAttributes(lp);
                                            }
                                        });
                                        dialogs.show();
                                        dialogs.getWindow().setAttributes(lp);
                                    }
                                });
                                therebtn.setText("مشغل خارجي");
                                therebtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialogs.dismiss();
                                        final Dialog dialogs = new Dialog(context);
                                        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        dialogs.setContentView(R.layout.menus);
                                        dialogs.setCancelable(true);
                                        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                        lp.copyFrom(dialogs.getWindow().getAttributes());
                                        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                        final AppCompatButton onebtn = dialogs.findViewById(R.id.onebtn);
                                        final AppCompatButton twobtn = dialogs.findViewById(R.id.twobtn);
                                        final AppCompatButton therebtn = dialogs.findViewById(R.id.therebtn);
                                        therebtn.setVisibility(View.GONE);
                                        onebtn.setText("الدقة الضعيفة");
                                        onebtn.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                if (mInterstitialAd.isLoaded()) {
                                                    mInterstitialAd.show();
                                                    mInterstitialAd = new InterstitialAd(context);
                                                    mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                                } else {
                                                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                                                }
                                                dialogs.dismiss();
                                                JSONObject ary = null;
                                                try {
                                                    ary = new JSONObject(imageToBitmap.DDA(data));
                                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                                    intent.setDataAndType(Uri.parse(ary.getString("sd")), "video/*");
                                                    context.startActivity(Intent.createChooser(intent, "أختيار المشغل"));
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        twobtn.setText("الدقة العالية");
                                        twobtn.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                if (mInterstitialAd.isLoaded()) {
                                                    mInterstitialAd.show();
                                                    mInterstitialAd = new InterstitialAd(context);
                                                    mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                                } else {
                                                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                                                }
                                                dialogs.dismiss();
                                                JSONObject ary = null;
                                                try {
                                                    ary = new JSONObject(imageToBitmap.DDA(data));
                                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                                    intent.setDataAndType(Uri.parse(ary.getString("hd")), "video/*");
                                                    context.startActivity(Intent.createChooser(intent, "أختيار المشغل"));
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        dialogs.show();
                                        dialogs.getWindow().setAttributes(lp);
                                    }
                                });
                                dialogs.show();
                                dialogs.getWindow().setAttributes(lp);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else {
                            dl.setFailedText("توجد مشكلة في الشبكة تحقق منه وأعد المحاولة");
                            dl.loadFailed();
                        }
                    }
                });
    }
    private static void Download(String url, String name,Context context) {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
            mInterstitialAd = new InterstitialAd(context);
            mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } else {
            Log.d("TAG", "The interstitial wasn't loaded yet.");
        }
        DownloadManager downloadmanager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri = Uri.parse(url);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setTitle("يتم التنزيل");
        request.setDescription(name);//request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name+".mp4");
        downloadmanager.enqueue(request);
    }
}