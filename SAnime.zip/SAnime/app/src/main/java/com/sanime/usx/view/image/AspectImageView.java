package com.sanime.usx.view.image;

import android.content.Context;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.Display;
import android.view.WindowManager;

import com.sanime.usx.R;
import com.sanime.usx.view.CustomView;


/**
 * Created by max on 2017/09/01.
 * Custom image view that can respect a given aspect view ratio,
 * either specify the width of the image and the height will be automatically calculated
 * or set to wrap content to automatically get the view width at runtime
 */

public class AspectImageView extends androidx.appcompat.widget.AppCompatImageView implements CustomView {

    private int spanSize;
    private int defaultMargin;
    private Point deviceDimens = new Point();

    public AspectImageView(Context context) {
        super(context);
        onInit();
    }

    public AspectImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        onInit();
    }

    public AspectImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        onInit();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int Width;
        if((Width = MeasureSpec.getSize(widthMeasureSpec)) == 0)
            Width = (deviceDimens.x / spanSize) - defaultMargin;

        int Height = (int) (Width * 1.37f);
        super.onMeasure(MeasureSpec.makeMeasureSpec(Width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(Height, MeasureSpec.EXACTLY));
    }

    /**
     * Optionally included when constructing custom views
     */
    @Override
    public void onInit() {
        defaultMargin = getResources().getDimensionPixelSize(R.dimen.md_margin);
        spanSize = getResources().getInteger(R.integer.grid_list_x2);
        getScreenDimenss(deviceDimens,getContext());
    }

    /**
     * Clean up any resources that won't be needed
     */
    @Override
    public void onViewRecycled() {

    }

    private void getScreenDimenss(Point deviceDimens, Context context) {
        Display display = ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        display.getSize(deviceDimens);
    }
}
