package com.sanime.usx;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.sanime.usx.account.AccountUtil;
import com.sanime.usx.database.DatabaseHandler;
import com.sanime.usx.database.DatabaseWatching;
import com.sanime.usx.database.Favorite;
import com.sanime.usx.database.Watching;
import com.snatik.storage.Storage;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AnimeUtil {
    private static final int SECOND_MILLIS = 1000;
    private static final int MINUTE_MILLIS = 60 * SECOND_MILLIS;
    private static final int HOUR_MILLIS = 60 * MINUTE_MILLIS;
    private static final int DAY_MILLIS = 24 * HOUR_MILLIS;

    public static String getF() {
        String datas = "";
        byte[] data = Base64.decode("Y29tLnNub2FuaW1lLmVkZ2U=", Base64.DEFAULT);
        try {
            datas = new String(data, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return datas;
    }
    public static String getN() {
        String datas = "";
        byte[] data = Base64.decode("U25vQW5pbWU=", Base64.DEFAULT);
        try {
            datas = new String(data, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return datas;
    }
    public static void zipFolders(Context context, String inputFolderPath, String outZipPath) {
        String filepath = "";
        try {
            DatabaseWatching watching = new DatabaseWatching(context);
            DatabaseHandler fav = new DatabaseHandler(context);
            List<Favorite> contacts = fav.getAllFav();
            List<Watching> contactss = watching.getAllWatching();
            Gson s = new Gson();
            Gson s2 = new Gson();
            JSONObject object = new JSONObject();
            JSONArray array = new JSONArray(s.toJson(contacts));
            JSONArray array2 = new JSONArray(s2.toJson(contactss));
            object.put("favorite",array);
            object.put("watching",array2);
            Log.d("All Favorite", s.toJson(contacts));
            Log.d("All Watching", s2.toJson(contactss));
            try {
                File root = new File(outZipPath);
                if (!root.exists()) {
                    root.mkdirs();
                }
                File gpxfile = new File(root, "databases.txt");
                FileWriter writer = new FileWriter(gpxfile);
                writer.append(object.toString());
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception ioe) {
            filepath = "error make file ioe";
            Log.e("Error Get database", ioe.getMessage());
        }
    }

    public static void zipFolder(Context context,Activity activity) {
        String filepath = "";
        try {
            DatabaseWatching watching = new DatabaseWatching(context);
            DatabaseHandler fav = new DatabaseHandler(context);
            List<Favorite> contacts = fav.getAllFav();
            List<Watching> contactss = watching.getAllWatching();
            Storage storage = new Storage(context);
            if (storage.isFileExist(Environment.getExternalStorageDirectory()+"/Android/data/"+getF()+"/files/"+getN()+"/databases.txt")) {
                String data = storage.readTextFile(Environment.getExternalStorageDirectory()+"/Android/data/"+getF()+"/files/"+getN()+"/databases.txt");
                try {
                    JSONObject array = new JSONObject(data);
                    Log.d("DRF","Is : "  + array.getJSONArray("favorite").length());
                    for (int i = 0; i < array.getJSONArray("favorite").length(); i++) {
                            fav.addFav(new Favorite(array.getJSONArray("favorite").getJSONObject(i).getString("_id"),array.getJSONArray("favorite").getJSONObject(i).getString("_name"),array.getJSONArray("favorite").getJSONObject(i).getString("_image")));
                    }
                    for (int i = 0; i < array.getJSONArray("watching").length(); i++) {
                            String id = array.getJSONArray("watching").getJSONObject(i).getString("_id");
                            String animeid = array.getJSONArray("watching").getJSONObject(i).getString("_animeid");
                            String images = array.getJSONArray("watching").getJSONObject(i).getString("_image");
                            String mame = array.getJSONArray("watching").getJSONObject(i).getString("_name");
                            watching.addWatching(new Watching(id,mame,images,animeid));
                    }
                    AccountUtil.addBackup(activity);
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ioe) {
            filepath = "error make file ioe";
        }
    }

    public static void reActivity(Activity context, Class classs) {
        context.finish();
        context.startActivity(new Intent(context,classs));
        context.overridePendingTransition(R.anim.fadein, R.anim.fadeout);
    }
    public static void TrustSSL() {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }
                }
        };
        // Install the all-trusting trust manager
        // Try "SSL" or Replace with "TLS"
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String getTimeAgo(String data) {
        long time =  Long.parseLong(data);
        if (time < 1000000000000L) {
            time *= 1000;
        }

        long now = System.currentTimeMillis();
        if (time > now || time <= 0) {
            return null;
        }

        final long diff = now - time;
        if (diff < MINUTE_MILLIS) {
            return "الان";
        } else if (diff < 2 * MINUTE_MILLIS) {
            return "قبل دقيقة";
        } else if (diff < 50 * MINUTE_MILLIS) {
            return " منذ " + diff / MINUTE_MILLIS + " دقيقة ";
        } else if (diff < 90 * MINUTE_MILLIS) {
            return "قبل ساعة";
        } else if (diff < 24 * HOUR_MILLIS) {
            return " منذ " + diff / HOUR_MILLIS + " ساعة ";
        } else if (diff < 48 * HOUR_MILLIS) {
            return "قبل يوم";
        } else {
            return " منذ " + diff / DAY_MILLIS + " يوم ";
        }
    }
    public static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) { e.printStackTrace();}
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if(dir!= null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }
}
