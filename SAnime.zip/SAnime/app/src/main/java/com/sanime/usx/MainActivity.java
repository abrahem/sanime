package com.sanime.usx;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.signature.ObjectKey;
import com.gigamole.navigationtabstrip.NavigationTabStrip;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.sanime.usx.account.AccountUtil;
import com.sanime.usx.account.ReportActivity;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.ContactsAdapter;
import com.sanime.usx.adapter.SearchAdapter;
import com.sanime.usx.view.CircleImageView;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonCallback;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.widget.ImageViewCompat;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.Permission;
import java.util.ArrayList;
import java.util.List;

import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;

import static com.sanime.usx.AnimeUtil.TrustSSL;
import static com.sanime.usx.ui.community.CommunityFragment.ACTIV;
import static com.sanime.usx.ui.community.CommunityFragment.IMAGE;
import static com.sanime.usx.ui.community.CommunityFragment.LINEARPOST;
import static com.sanime.usx.ui.community.CommunityFragment.SWIPREFRESH;
import static com.sanime.usx.ui.community.CommunityFragment.newLine;
import static com.sanime.usx.ui.community.CommunityFragment.setCommant;
import static com.sanime.usx.ui.slideshow.SlideshowFragment.CONTENT;
import static com.sanime.usx.ui.slideshow.SlideshowFragment.URLS;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    public static NavigationTabStrip viewPagerTab;
    public static NavigationTabStrip viewPagerTab2;
    public static NavigationTabStrip viewPagerTab3;
    public static MainActivity VIEWS;
    public static String RESPONSE = "";
    public static String INFOS = "";
    public static boolean ISRES = false;
    private CircleImageView img;
    private Menu menu;
    public static Boolean isVisible = false;
    public static boolean hasFire = false;
    public static Boolean ifFive = false;
    public static boolean hasAnime = false;
    public static String post_image = "";
    public static LinearLayout giflinear;
    public static ImageView gifimage;
    public LinearLayout animepost;
    public static boolean packed = false;
    public static Bitmap image;
    public static ImageView imgss;
    public static String imgs = "";
    public static RequestNetwork requess;
    public static RequestNetwork.RequestListener _requests;
    public static JSONArray animearray = new JSONArray();
    public static InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        Dexter.withContext(getApplicationContext())
                .withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.INTERNET, Manifest.permission.ACCESS_WIFI_STATE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {

                    }
                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                        Dexter.withContext(getApplicationContext())
                                .withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                        Manifest.permission.INTERNET, Manifest.permission.ACCESS_WIFI_STATE)
                                .withListener(new MultiplePermissionsListener() {
                                    @Override
                                    public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                                    }

                                    @Override
                                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                                        finish();
                                    }
                                })
                                .withErrorListener(new PermissionRequestErrorListener() {
                                    @Override
                                    public void onError(DexterError dexterError) {
                                        Toast.makeText(getApplicationContext(),"توجد مشكلة في قرائة الصلاحيات",Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .check();
                    }
                })
                .withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError dexterError) {
                        Toast.makeText(getApplicationContext(),"توجد مشكلة في قرائة الصلاحيات",Toast.LENGTH_SHORT).show();
                    }
                })
                .check();
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        isVisible = false;
        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow, R.id.nav_community,R.id.nav_list)
                .setDrawerLayout(drawer)
                .build();
        VIEWS = this;
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        navigationView.setCheckedItem(R.id.nav_home);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        viewPagerTab = findViewById(R.id.viewpagertab);
        viewPagerTab2 = findViewById(R.id.myanime);
        viewPagerTab3 = findViewById(R.id.commu);
        View view = navigationView.getHeaderView(0);
        img = view.findViewById(R.id.profile_image);
        LinearLayout backg = view.findViewById(R.id.banneruser);
        TextView usernames = view.findViewById(R.id.username);
        ImageView premiumc = view.findViewById(R.id.premium);
        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
                if (destination.getLabel().toString().contains("المشاهدة")) {
                    if (isVisible) {
                        menu.findItem(R.id.makepost).setVisible(false);
                    }
                    viewPagerTab.setVisibility(View.VISIBLE);
                    viewPagerTab2.setVisibility(View.GONE);
                    viewPagerTab3.setVisibility(View.GONE);
                } else {
                    if (destination.getLabel().toString().contains("أنمياتك")) {
                        if (isVisible) {
                            menu.findItem(R.id.makepost).setVisible(false);
                        }
                        viewPagerTab.setVisibility(View.GONE);
                        viewPagerTab2.setVisibility(View.VISIBLE);
                        viewPagerTab3.setVisibility(View.GONE);
                    } else {
                        if (destination.getLabel().toString().contains("المجتمع")) {
                            isVisible = true;
                            try {
                                menu.findItem(R.id.makepost).setVisible(true);
                            } catch (Exception e) {

                            }
                            viewPagerTab2.setVisibility(View.GONE);
                            viewPagerTab.setVisibility(View.GONE);
                            viewPagerTab3.setVisibility(View.VISIBLE);
                        } else {
                            if (isVisible) {
                                menu.findItem(R.id.makepost).setVisible(false);
                            }
                            viewPagerTab2.setVisibility(View.GONE);
                            viewPagerTab.setVisibility(View.GONE);
                            viewPagerTab3.setVisibility(View.GONE);
                        }
                    }
                }
            }
        });
        if (!AccountUtil.ifRestored(MainActivity.this)) {
            try {
                AnimeUtil.zipFolder(getApplicationContext(),MainActivity.this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (getDatabasePath("/data/data/com.sanime.usx/databases").isDirectory()) {
            AnimeUtil.zipFolders(getApplicationContext(),"",getExternalFilesDir("/SAnime").getAbsolutePath());
        }
        if (AccountUtil.isLogin(MainActivity.this)) {
            navigationView.getMenu().findItem(R.id.updatetest).setVisible(true);
            if (AccountUtil.isPremium(MainActivity.this)) {
                backg.setBackgroundResource(R.drawable.bannergold);
                premiumc.setVisibility(View.VISIBLE);
                usernames.setTextColor(Color.parseColor(AccountUtil.getPremiumColor(MainActivity.this)));
            } else {
                backg.setBackgroundResource(R.drawable.banner);
                premiumc.setVisibility(View.GONE);
            }
            usernames.setText(AccountUtil.getUsername(MainActivity.this));
            Glide.with(MainActivity.this).load(Uri.parse(AccountUtil.getImage(MainActivity.this))).signature(new ObjectKey(String.valueOf(System.currentTimeMillis())))
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            LoadAgain(MainActivity.this,img);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            return false;
                        }
                    }).into(img);
            navigationView.getMenu().findItem(R.id.nav_sign_out).setVisible(true);
            navigationView.getMenu().findItem(R.id.profile).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_sign_in).setVisible(false);
            navigationView.getMenu().findItem(R.id.nav_sign_up).setVisible(false);
            if (AccountUtil.isAdmin(MainActivity.this)) {
                navigationView.getMenu().findItem(R.id.reportlist).setVisible(true);
            }
        } else {
            navigationView.getMenu().findItem(R.id.updatetest).setVisible(false);
        }
    }
    public static void LoadAgain(Activity activity,ImageView img) {
        Glide.with(activity).load(Uri.parse(AccountUtil.getImage(activity))).signature(new ObjectKey(String.valueOf(System.currentTimeMillis())))
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        LoadAgain(activity,img);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                }).into(img);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        this.menu = menu;
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        Boolean nu = false;
        switch (item.getItemId()) {
            case R.id.searchanime:
                startActivity(new Intent(MainActivity.this,Search.class));
                nu = true;
                break;
            case R.id.makepost:
                makePOST(MainActivity.this);
                break;
            case R.id.share:
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody =  "تطبيق أس أنمي أفضل تطبيق لمشاهدة ألانمي بدقات وسيرفرات متعددة يمكنكم تحميلة من الرابط التالي" + newLine() + "https://play.google.com/store/apps/details?id=com.sanime.usx";
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "مشاركة عبر"));
                break;
            case R.id.privacy:
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://abrahem.github.io/sanime/privacy.html"));
                startActivity(browserIntent);
                break;
            case R.id.terms:
                Intent browserIntents = new Intent(Intent.ACTION_VIEW, Uri.parse("https://abrahem.github.io/sanime/tos.html"));
                startActivity(browserIntents);
                break;
            case R.id.librarys:
                Intent browserIntent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://abrahem.github.io/sanime/libraries.html"));
                startActivity(browserIntent2);
                break;
        }
        return nu;
    }
    public static boolean check5() {
        if (ifFive) {
            return false;
        } else {
            ifFive = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    ifFive = false;
                }
            },300000);
            return true;
        }
    }
    private void makePOST(Context context) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_add_post);
        dialog.setCancelable(true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        final String[] command = {""};
        final AppCompatButton bt_submit =  dialog.findViewById(R.id.bt_submit);
        final AppCompatButton bt_submit2 =  dialog.findViewById(R.id.bt_submit2);
        final CircularImageView img = dialog.findViewById(R.id.userimgpost) ;
        final TextView txt = dialog.findViewById(R.id.userpost) ;
        final AppCompatCheckBox bx = dialog.findViewById(R.id.checkpost);
        final LinearLayout animepost2 = dialog.findViewById(R.id.animepost);
        final LinearLayout giflinears = dialog.findViewById(R.id.giflinear);
        final ImageView gifimages = dialog.findViewById(R.id.imagegif);
        final ImageButton removeimage = dialog.findViewById(R.id.removeimage);
        removeimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Glide.with(context).load(Uri.parse("https://google.com")).into(gifimages);
                giflinear.setVisibility(View.GONE);
            }
        });
        gifimage = gifimages;
        giflinear = giflinears;
        animepost = animepost2;
        bx.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    hasFire = isChecked;
                } else {
                    hasFire = false;
                }
            }
        });
        if (AccountUtil.isLogin(context)) {
            txt.setText(AccountUtil.getUsername(context));
            Glide.with(context).load(Uri.parse(AccountUtil.getImage(context))).into(img);
        } else {
            dialog.dismiss();
            Toast.makeText(context,"يجب عليك أنشاء حساب",Toast.LENGTH_SHORT).show();
        }

        ((EditText) dialog.findViewById(R.id.et_post)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                command[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        bt_submit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"يرجى الانتظار 5 دقائق لعمل منشور مرى أخرى",Toast.LENGTH_LONG).show();
            }
        });
        bt_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainActivity.check5()) {
                    Boolean bln = AccountUtil.isLogin(context);
                    if (bln) {
                            final LoadingDialog ld = new LoadingDialog(context);
                            ld.setLoadingText("جار النشر").show();
                            HttpAgent.post(MainActivity.getApi("data/user/post.php"))
                                .setTimeOut(10000)
                                .headers("Content-Type", "application/x-www-form-urlencoded")
                                .withBody("username="+AccountUtil.getUsername(context)+"&password="+AccountUtil.getPassword(context)+"&post="+command[0]+"&time="+System.currentTimeMillis()+"&hasFire="+hasFire+"&hasAnime="+hasAnime+"&anime="+animearray.toString()+"&hasImage="+post_image)
                                    .goString(new StringCallback() {
                                    @Override
                                    protected void onDone(boolean success, String response) {
                                        if (success) {
                                            ld.setSuccessText(response);
                                            ld.loadSuccess();
                                            dialog.dismiss();
                                            View views = new View(context);
                                            setCommant(ACTIV,LINEARPOST,SWIPREFRESH,views);
                                            if (mInterstitialAd.isLoaded()) {
                                                mInterstitialAd.show();
                                                mInterstitialAd = new InterstitialAd(context);
                                                mInterstitialAd.setAdUnitId("ca-app-pub-9372585201524216/7240417037");
                                                mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                            } else {
                                                Log.d("TAG", "The interstitial wasn't loaded yet.");
                                            }
                                        } else {
                                            ld.setFailedText("توجد مشكلة في الشبكة حاول مرى أخرى");
                                            ld.loadFailed();
                                        }
                                    }
                                });
                    } else {
                        Toast.makeText(context,"يجب عليك أنشاء حساب",Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context,"يرجى الانتظار 5 دقائق لعمل منشور مرى اخرى",Toast.LENGTH_SHORT).show();
                }
            }
        });
        ((ImageButton) dialog.findViewById(R.id.addanime)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSearch(context);
            }
        });
        ((ImageButton) dialog.findViewById(R.id.addImage)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (AccountUtil.isLogin(context)) {
                    if (IMAGE) {
                        AlertDialog.Builder posts = new AlertDialog.Builder(context);
                        posts.setTitle("قم أضافة رابط الصورة");
                        final EditText input = new EditText(context);
                        input.setHint("أكتب الرابط هنا");
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.MATCH_PARENT);
                        input.setLayoutParams(lp);
                        posts.setView(input);
                        posts.setNegativeButton("أضافة", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String message = input.getText().toString();
                                if (isValid(message)) {
                                    dialog.dismiss();
                                    showMessage("تم أضافة الصورة",context);
                                    post_image = message;
                                    giflinear.setVisibility(View.VISIBLE);
                                    if (message.contains("gif")) {
                                        Glide.with(context).asGif().load(Uri.parse(message)).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimages);
                                    } else {
                                        Glide.with(context).load(Uri.parse(message)).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimages);
                                    }
                                } else {
                                    input.setText("");
                                    showMessage("الرابط غير صحيح قم بأضافة رابط صالح",context);
                                }
                            }
                        });
                        posts.create().show();
                    } else {
                        if (AccountUtil.isPremium(context)) {
                            AlertDialog.Builder posts = new AlertDialog.Builder(context);
                            posts.setTitle("قم بأضافة رابط الصورة");
                            final EditText input = new EditText(context);
                            input.setHint("أكتب الرابط هنا");
                            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.MATCH_PARENT);
                            input.setLayoutParams(lp);
                            posts.setView(input);
                            posts.setNegativeButton("أضافة", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    String message = input.getText().toString();
                                    if (isValid(message)) {
                                        dialog.dismiss();
                                        showMessage("تم أضافة الصورة",context);
                                        post_image = message;
                                        giflinear.setVisibility(View.VISIBLE);
                                        if (message.contains("gif")) {
                                            Glide.with(context).asGif().load(Uri.parse(message)).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimages);
                                        } else {
                                            Glide.with(context).load(Uri.parse(message)).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimages);
                                        }
                                    } else {
                                        input.setText("");
                                        showMessage("الرابط غير صحيح قم بأضافة رابط صالح",context);
                                    }
                                }
                            });
                            posts.create().show();
                        } else {
                            showMessage("هذا الميزة مخصصة للعضوية الذهبية فقط",context);
                        }
                    }
                } else {
                    showMessage("يجب عليك أنشاء حساب لكي تقوم بنشر صورة",context);
                }
            }
        });
        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
    public static String getApi(String path) {
        String datass = "";
        if (Build.VERSION.SDK_INT < 24) {
            String datas = "";
            byte[] data = Base64.decode("aHR0cDovL2FwaS5zbm9hbmltZS5jb20=", Base64.DEFAULT);
            try {
                datas = new String(data, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            datass = datas+"/"+path;
        } else {
            String datas = "";
            byte[] data = Base64.decode("aHR0cHM6Ly9zbm9hbmltZS5jb20=", Base64.DEFAULT);
            try {
                datas = new String(data, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            datass = datas+"/"+path;
        }
        return datass;
    }
    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
    public static boolean isValid(String url)
    {
        /* Try creating a valid URL */
        try {
            new URL(url).toURI();
            return true;
        }

        // If there was an Exception
        // while creating URL object
        catch (Exception e) {
            return false;
        }
    }
    private void openSearch(Context context) {
        final Dialog dialogs = new Dialog(context);
        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogs.setContentView(R.layout.search_anime);
        dialogs.setCancelable(true);
        final ImageButton btn = dialogs.findViewById(R.id.searchan);
        final TextInputEditText sear  = dialogs.findViewById(R.id.animeinput);
        final LinearLayout search = dialogs.findViewById(R.id.animesearch);
        sear.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    btn.performClick();
                    return true;
                }
                return false;
            }
        });
        final String[] name = {""};
        ((TextInputEditText) dialogs.findViewById(R.id.animeinput)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                name[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final LoadingDialog ld = new LoadingDialog(context);
                ld.setLoadingText("يرجى الانتظار").show();
                String url = MainActivity.getApi("data/search.php/?name=");
                String q = name[0];
                String urls = null;
                try {
                    urls = url + URLEncoder.encode(q, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                HttpAgent.get(urls)
                        .setTimeOut(10000)
                        .goString(new StringCallback() {
                            @Override
                            protected void onDone(boolean success, String response) {
                                if (success) {
                                    sear.setText("");
                                    ld.close();
                                    JSONArray ary = null;
                                    if (response.contains("[]")) {
                                        Toast.makeText(context,"لا توجد انميات بهذا الاسم حاول كتابة الاسم بطريقة صحيحة",Toast.LENGTH_SHORT).show();
                                    }
                                    try {
                                        ary = new JSONArray(response);
                                        GridLayoutManager gridLayoutManager3;
                                        RecyclerView rvContacts3 = dialogs.findViewById(R.id.rvContacts4);
                                        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                                            gridLayoutManager3 = new GridLayoutManager(getApplicationContext(),2, LinearLayoutManager.VERTICAL,false);
                                        }
                                        else{
                                            gridLayoutManager3 = new GridLayoutManager(getApplicationContext(),4, LinearLayoutManager.VERTICAL,false);
                                        }
                                        rvContacts3.setLayoutManager(gridLayoutManager3); // set LayoutManager to RecyclerView
                                        ArrayList<Anime> contacts3 = new ArrayList<Anime>();
                                        JSONArray finalAry = ary;
                                        SearchAdapter adapter3 = new SearchAdapter(contacts3, new ClickInterface() {
                                            @Override
                                            public void itemClicked(int position) {
                                                try {
                                                    if(animearray.length() < 10) {
                                                        animepost.removeAllViews();
                                                        showMessage("تم اضافة الانمي",context);
                                                        hasAnime = true;
                                                        JSONObject object = new JSONObject();
                                                        object.put("id",finalAry.getJSONObject(position).getString("id"));
                                                        object.put("name", finalAry.getJSONObject(position).getString("name"));
                                                        object.put("image", finalAry.getJSONObject(position).getString("image"));
                                                        animearray.put(object);
                                                        for(int g=0; g<animearray.length(); g++) {
                                                            View views = LayoutInflater.from(context).inflate(R.layout.otherlist, null);
                                                            final ImageView imagess = (ImageView) views.findViewById(R.id.exampleimg);
                                                            final LinearLayout linear2 = (LinearLayout) views.findViewById(R.id.linear2);
                                                            final ProgressBar loadings = (ProgressBar) views.findViewById(R.id.prof);
                                                            final TextView textview2 = (TextView) views.findViewById(R.id.exampletxt2);
                                                            textview2.setText(animearray.getJSONObject(g).getString("name"));
                                                            final int finalI = g;
                                                            Glide.with(context)
                                                                    .load(Uri.parse(animearray.getJSONObject(g).getString("image")))
                                                                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                                                                    .listener(new RequestListener<Drawable>() {
                                                                        @Override
                                                                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                                                            return false;
                                                                        }
                                                                        @Override
                                                                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                                                            loadings.setVisibility(View.GONE);
                                                                            return false;
                                                                        }
                                                                    })
                                                                    .into(imagess);
                                                            views.setId(g);
                                                            animepost.addView(views);
                                                        }
                                                    } else {
                                                        showMessage("غير مسموح لك اضافة أكثر من 10 انميات في المنشور",context);
                                                    }
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                        for (int is = 0; is < ary.length(); is++) {
                                            contacts3.add(new Anime(ary.getJSONObject(is).getString("name"),ary.getJSONObject(is).getString("status"),ary.getJSONObject(is).getString("image"),ary.getJSONObject(is).getString("id")));
                                        }
                                        rvContacts3.setAdapter(adapter3);
                                        rvContacts3.getAdapter().notifyDataSetChanged();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    ld.setFailedText(getErrorMessage());
                                    ld.loadFailed();
                                }
                            }
                        });
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialogs.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialogs.show();
        dialogs.getWindow().setAttributes(lp);
    }
    public static void showMessage(String s,Context context) {
        Toast.makeText(context,s,Toast.LENGTH_SHORT).show();
    }
    public static void onClickCalled(int position ,SearchAdapter.ViewHolder viewHolder) {
        // Call another acitivty here and pass some arguments to it.
    }
    public void login(MenuItem item) {
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.login);
                dialog.setCancelable(true);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(dialog.getWindow().getAttributes());
                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                final String[] usernm = {""};
                final String[] passw = {""};
                final Button bt_submit = (Button) dialog.findViewById(R.id.bt_submit);
                ((TextInputEditText) dialog.findViewById(R.id.username)).addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        usernm[0] = s.toString();
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                ((TextInputEditText) dialog.findViewById(R.id.password)).addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        bt_submit.setEnabled(!s.toString().trim().isEmpty());
                        passw[0] = s.toString();

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                bt_submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AccountUtil.Login(usernm[0],passw[0],MainActivity.this,dialog,MainActivity.this);
                    }
                });
                dialog.show();
                dialog.getWindow().setAttributes(lp);
    }

    public void logout(MenuItem item) {
        AccountUtil.Logout(getApplicationContext(),MainActivity.this);
    }

    public void settings(MenuItem item) {
        AccountUtil.updateAcc(MainActivity.this,getApplicationContext());
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        EasyImage.handleActivityResult(requestCode, resultCode, data, MainActivity.this, new DefaultCallback() {
            @Override
            public void onImagesPicked(@NonNull List<File> imageFiles, EasyImage.ImageSource source, int type) {
                packed = true;
                Bitmap bm = BitmapFactory.decodeFile(imageFiles.get(0).getAbsolutePath());
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.PNG, 25, baos); //bm is the bitmap object
                image = bm;
                byte[] b = baos.toByteArray();
                imgs = Base64.encodeToString(b, Base64.DEFAULT);
                imgs = imgs.replace("\n", "").replace("\r", "");
                Toast.makeText(getApplicationContext(),"تم رفع الصورة",Toast.LENGTH_LONG).show();
                imgss.setImageBitmap(bm);
            }
        });
    }

    public String addImage(String image) {
        Bitmap bm = BitmapFactory.decodeFile(image);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
        byte[] b = baos.toByteArray();
        return Base64.encodeToString(b, Base64.DEFAULT);
    }

    public void register(MenuItem item) {
        AccountUtil.SignUp(MainActivity.this,getApplicationContext());
    }

    public void report(MenuItem item) {
        startActivity(new Intent(MainActivity.this, ReportActivity.class));
    }

    public void profile(MenuItem item) {
        final LoadingDialog ld = new LoadingDialog(MainActivity.this);
        ld.setLoadingText("يرجى الانتظار").show();
        HttpAgent.get(MainActivity.getApi("data/user/profile.php/?username="+ AccountUtil.getUsername(MainActivity.this)))
                .setTimeOut(10000)
                .goString(new StringCallback() {
                    @Override
                    protected void onDone(boolean success, String stringResults) {
                        if (success) {
                            ld.close();
                            try {
                                JSONObject obj = new JSONObject(stringResults);
                                AccountUtil.openProfile(obj,MainActivity.this);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else {
                            ld.close();
                            MainActivity.showMessage(getErrorMessage(),MainActivity.this);
                        }
                    }
                });
    }
}