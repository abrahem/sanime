package com.sanime.usx.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import java.util.List;
import com.sanime.usx.ClickInterface;
public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {
        // ... view holder defined above...
        // Store a member variable for the contacts
        private List<Anime> mContacts;
        public final ClickInterface listener;
    // Pass in the contact array into the constructor
        public SearchAdapter(List<Anime> Anime,ClickInterface listener) {
            mContacts = Anime;
            this.listener = listener;
        }
    public class ViewHolder extends RecyclerView.ViewHolder{
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView nameTextView;
        public TextView messageButton;
        public ImageView img;
        public CardView container;
        public Context context;
        public AdapterView.OnItemClickListener onItemClickListener;
        public ViewHolder(Context context, View itemView) {
            super(itemView);
            this.context = context;
            this.nameTextView = (TextView) itemView.findViewById(R.id.series_title);
            this.messageButton = (TextView) itemView.findViewById(R.id.title2);
            this.container = (CardView) itemView.findViewById(R.id.container);
            this.img = (ImageView) itemView.findViewById(R.id.series_image);
            container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.itemClicked(getAdapterPosition());
                }
            });
            // Store the context
        }
    }
    @Override
    public SearchAdapter.ViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        final Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.lists, parent, false);
        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(context,contactView);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(final SearchAdapter.ViewHolder viewHolder, int position) {
        // Get the data model based on position
        final Anime contact = mContacts.get(position);
        // Set item views based on your views and data model
        TextView textView = viewHolder.nameTextView;
        textView.setText(contact.getName());
        TextView button = viewHolder.messageButton;
        CardView vi = viewHolder.container;
        ImageView img = viewHolder.img;
        Glide.with(viewHolder.context).load(Uri.parse(contact.getImage())).into(img);
        button.setText(contact.getTitle());
        MainActivity.onClickCalled(position,viewHolder);

    }
    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return mContacts.size();
    }
}