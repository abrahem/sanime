package com.sanime.usx.database;

public class Watching {
    String _id;
    String _name;
    String _image;
    String _animeid;
    public Watching(){   }
    public Watching(String id, String name, String _image, String animeid){
        this._id = id;
        this._name = name;
        this._image = _image;
        this._animeid = animeid;
    }

    public Watching(String name, String _image){
        this._name = name;
        this._image = _image;
    }
    public String getID(){
        return this._id;
    }
    public String getAnimeID(){
        return this._animeid;
    }

    public void setAnimeID(String animeID){
        this._animeid = animeID;
    }

    public void setID(String id){
        this._id = id;
    }

    public String getName(){
        return this._name;
    }

    public void setName(String name){
        this._name = name;
    }

    public String getImageUrl(){
        return this._image;
    }

    public void setImageUrl(String phone_number){
        this._image = phone_number;
    }
}