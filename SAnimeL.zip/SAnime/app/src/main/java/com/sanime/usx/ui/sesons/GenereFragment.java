package com.sanime.usx.ui.sesons;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager.widget.ViewPager;

import com.sanime.usx.AllAnime;
import com.sanime.usx.AllAnime2;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.adapter.AnimeWatching;
import com.sanime.usx.adapter.FavAdapter;
import com.sanime.usx.adapter.WatchingAdapter;
import com.sanime.usx.database.DatabaseHandler;
import com.sanime.usx.database.DatabaseWatching;
import com.sanime.usx.database.Watching;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonCallback;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.sanime.usx.MainActivity.GENEREANDSEASON;
import static com.sanime.usx.MainActivity.showMessage;
import static com.sanime.usx.MainActivity.viewPagerTab4;

public class GenereFragment extends Fragment {
    public static String GENEREANIME = "";
    public static String GENERENAME = "";
    private GenereViewModel galleryViewModel;
    public static DatabaseHandler fav;
    public static DatabaseWatching watch;
    public static FragmentActivity ACTIVITYFAV;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GenereViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery2, container, false);
        LoadingDialog dialog = new LoadingDialog(getActivity());
        dialog.setLoadingText("يرجى الانتظار").show();
        HttpAgent.get(MainActivity.getApi("data/listgenere.php"))
                .setTimeOut(10000)
                .goJson(new JsonCallback() {
                    @Override
                    protected void onDone(boolean success, JSONObject stringResults) {
                        dialog.close();
                        if (success) {
                            DemoCollectionPagerAdapter demoCollectionPagerAdapter = new DemoCollectionPagerAdapter(getChildFragmentManager());
                            ViewPager viewPager = root.findViewById(R.id.viewpager);
                            viewPager.setAdapter(demoCollectionPagerAdapter);
                            viewPagerTab4.setViewPager(viewPager);
                            GENEREANDSEASON = new JSONObject();
                            GENEREANDSEASON = stringResults;
                        } else {
                            MainActivity.showMessage("توجد مشكلة في الشبكة",getActivity());
                        }
                    }
                });
        return root;
    }
    public class DemoCollectionPagerAdapter extends FragmentStatePagerAdapter {
        public DemoCollectionPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {
            Fragment fragment = new DemoObjectFragment();
            Bundle args = new Bundle();
            // Our object is just an integer :-P
            args.putInt(DemoObjectFragment.ARG_OBJECT, i + 1);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            CharSequence string = "";
            switch (position) {
                case 0:
                    string = "التصنيفات";
                    break;
                case 1:
                    string = "المواسم";
                    break;
            }
            return string;
        }
    }
    public static class DemoObjectFragment extends Fragment {
        public static final String ARG_OBJECT = "object";

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            Bundle args = getArguments();
            ACTIVITYFAV = getActivity();
            View view;
            switch (args.getInt("object")) {
                case 1:
                    view = inflater.inflate(R.layout.fragmentgenere, container, false);
                    break;
                case 2:
                    view = inflater.inflate(R.layout.fragmentgenere2, container, false);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + args.getInt("object"));
            }
            return view;
        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            RecyclerView rvContacts = view.findViewById(R.id.rvContacts);
            RecyclerView rvContacts2 = view.findViewById(R.id.rvContacts2);
            Bundle args = getArguments();
            try {
                switch (args.getInt("object")) {
                    case 1:
                        try {
                            final LinearLayout epsoide = view.findViewById(R.id.generes);
                            for (int i = 0; i < GENEREANDSEASON.getJSONArray("genere").length(); i++) {
                                View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ep, null);
                                final TextView names = views.findViewById(R.id.nameep);
                                final ImageView wa = views.findViewById(R.id.watching);
                                names.setText(GENEREANDSEASON.getJSONArray("genere").getJSONObject(i).getString("name"));
                                final CardView cardview = views.findViewById(R.id.container);
                                int finalI = i;
                                cardview.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        try {
                                            LoadingDialog ld = new LoadingDialog(getContext());
                                            ld.setLoadingText("يرجى الانتظار");
                                            ld.show();
                                            HttpAgent.get(MainActivity.getApi(GENEREANDSEASON.getJSONArray("genere").getJSONObject(finalI).getString("link")))
                                                    .setTimeOut(10000)
                                                    .goString(new StringCallback() {
                                                        @Override
                                                        protected void onDone(boolean success, String stringResults) {
                                                            ld.close();
                                                            if (success) {
                                                                try {
                                                                    GENEREANIME = stringResults;
                                                                    GENERENAME = GENEREANDSEASON.getJSONArray("genere").getJSONObject(finalI).getString("name");
                                                                    startActivity(new Intent(getContext(), AllAnime2.class));
                                                                } catch (JSONException e) {
                                                                    e.printStackTrace();
                                                                }
                                                            } else {
                                                                Toast.makeText(getContext(),"توجد مشكلة في الشبكة",Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    });
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                                views.setId(i);
                                epsoide.addView(views);
                            }

                        } catch (JSONException E) {
                            E.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            final LinearLayout epsoide = view.findViewById(R.id.generes);
                            for (int i = 0; i < GENEREANDSEASON.getJSONArray("season").length(); i++) {
                                View views = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ep, null);
                                final TextView names = views.findViewById(R.id.nameep);
                                final ImageView wa = views.findViewById(R.id.watching);
                                names.setText(GENEREANDSEASON.getJSONArray("season").getJSONObject(i).getString("season_title"));
                                final CardView cardview = views.findViewById(R.id.container);
                                int finalI = i;
                                cardview.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        try {
                                            LoadingDialog ld = new LoadingDialog(getContext());
                                            ld.setLoadingText("يرجى الانتظار");
                                            ld.show();
                                            HttpAgent.get(MainActivity.getApi(GENEREANDSEASON.getJSONArray("season").getJSONObject(finalI).getString("link")))
                                                    .setTimeOut(10000)
                                                    .goString(new StringCallback() {
                                                        @Override
                                                        protected void onDone(boolean success, String stringResults) {
                                                            ld.close();
                                                            if (success) {
                                                                try {
                                                                    GENEREANIME = stringResults;
                                                                    GENERENAME = GENEREANDSEASON.getJSONArray("season").getJSONObject(finalI).getString("season_title");
                                                                    startActivity(new Intent(getContext(), AllAnime2.class));
                                                                } catch (JSONException e) {
                                                                    e.printStackTrace();
                                                                }
                                                            } else {
                                                                Toast.makeText(getContext(),"توجد مشكلة في الشبكة",Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    });
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                                views.setId(i);
                                epsoide.addView(views);
                            }

                        } catch (JSONException E) {
                            E.printStackTrace();
                        }
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}