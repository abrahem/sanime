package com.sanime.usx.database;

public class Favorite {
    String _id;
    String _name;
    String _image;
    public Favorite(){   }
    public Favorite(String id, String name, String image){
        this._id = id;
        this._name = name;
        this._image = image;
    }

    public Favorite(String name, String image){
        this._name = name;
        this._image = image;
    }
    public String getID(){
        return this._id;
    }

    public void setID(String id){
        this._id = id;
    }

    public String getName(){
        return this._name;
    }

    public void setName(String name){
        this._name = name;
    }

    public String getImageUrl(){
        return this._image;
    }

    public void setImageUrl(String phone_number){
        this._image = phone_number;
    }
}