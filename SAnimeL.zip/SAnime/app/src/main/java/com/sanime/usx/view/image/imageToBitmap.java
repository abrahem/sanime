package com.sanime.usx.view.image;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;

public class imageToBitmap {

    public static String imagebitmap = "";
    protected static String imagetostring(String image) {
        try {
            JSONArray arr = new JSONArray(image);
            StringBuilder data = new StringBuilder();
            StringBuilder data2 = new StringBuilder();

            for (int i = 0; i < arr.length(); i++) {
                data.append(arr.get(i).toString());
            }
            byte[] decodeValue = Base64.decode(data.toString().getBytes(), Base64.DEFAULT);
            String datas = new String(decodeValue);
            JSONArray ar2 = new JSONArray(datas);
            JSONArray newJsonArray = new JSONArray();
            for (int i = ar2.length()-1; i>=0; i--) {
                newJsonArray.put(ar2.get(i));
            }
            for (int i = 0; i < newJsonArray.length(); i++) {
                data2.append(newJsonArray.get(i).toString());
            }
            byte[] decodeValue2 = Base64.decode(data2.toString().getBytes(), Base64.DEFAULT);
            String datas2 = new String(decodeValue2);
            imagebitmap = datas2;
        } catch (JSONException e) {
            e.printStackTrace();
            imagebitmap = "error make image";
        }
        return imagebitmap;
    }

    public static String DDA(String imagebitmaps) {
        String dataimg = imagetostring(imagebitmaps);
        return dataimg;
    }
}