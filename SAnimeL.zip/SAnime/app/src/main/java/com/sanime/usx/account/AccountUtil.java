package com.sanime.usx.account;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.github.kevinsawicki.http.HttpRequest;
import com.google.android.material.textfield.TextInputEditText;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.sanime.usx.AnimeUtil;
import com.sanime.usx.ClickInterface;
import com.sanime.usx.MainActivity;
import com.sanime.usx.R;
import com.sanime.usx.adapter.Anime;
import com.sanime.usx.info.InfoActivity;
import com.sanime.usx.ui.community.CommunityFragment;
import com.sanime.usx.view.CircleImageView;
import com.sanime.usx.view.image.imageToBitmap;
import com.studioidan.httpagent.HttpAgent;
import com.studioidan.httpagent.JsonCallback;
import com.studioidan.httpagent.StringCallback;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cz.msebera.android.httpclient.entity.mime.Header;
import pl.aprilapps.easyphotopicker.EasyImage;
import static com.sanime.usx.MainActivity.getApi;
import static com.sanime.usx.MainActivity.imgs;
import static com.sanime.usx.MainActivity.imgss;
import static com.sanime.usx.MainActivity.packed;
import static com.sanime.usx.MainActivity.showMessage;
import static com.sanime.usx.ui.community.CommunityFragment.getLineCount;
import static com.sanime.usx.ui.community.CommunityFragment.newLine;
import static com.sanime.usx.ui.community.CommunityFragment.openCMD;

public class AccountUtil {

    public static LoadingDialog loadingDialog;
    public static Context CONTEXT;
    public static Activity ACTIVITY;
    public static Class MainActivityClass;
    public static void Login(String username, String password, Context context, Dialog dialog,Activity activity) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        final LoadingDialog ld = new LoadingDialog(context);
        ld.setLoadingText("يتم تسجيل الدخول").show();
        HttpAgent.post(MainActivity.getApi("data/user/login.php"))
                .setTimeOut(10000)
                .headers("Content-Type", "application/x-www-form-urlencoded")
                .withBody("username="+username+"&password="+password)
                .goJson(new JsonCallback() {
                    @Override
                    protected void onDone(boolean success, JSONObject jsonObject) {
                        String response = getStringResults();
                        if (success) {
                            try {
                                JSONObject obj = new JSONObject(response);
                                if (obj.getBoolean("status")) {
                                    ld.setOnFinishListener(new LoadingDialog.OnFinshListener() {
                                        @Override
                                        public void onFinish() {
                                            AnimeUtil.reActivity(activity,activity.getClass());
                                        }
                                    });
                                    ld.setSuccessText(obj.getString("code"));
                                    ld.loadSuccess();
                                    dialog.dismiss();
                                    sharedPref.edit().putBoolean("status", obj.getBoolean("status")).apply();
                                    sharedPref.edit().putString("profile", obj.getJSONObject("profile").toString()).apply();
                                } else {
                                    ld.setFailedText(obj.getString("code"));
                                    ld.loadFailed();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                ld.setFailedText("صيانة في السيرفر");
                                ld.loadFailed();
                            }
                        } else {
                            ld.close();
                            Toast.makeText(context,getErrorMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    public static void reportPost(Context context,String time,String user,String post,String users) {
        AlertDialog.Builder posts = new AlertDialog.Builder(context);
        posts.setTitle("منشور : "+users);
        final EditText input = new EditText(context);
        input.setHint("أكتب سبب البلاغ");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        posts.setView(input);
        posts.setNegativeButton("أرسال", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String message = input.getText().toString();
                dialog.dismiss();
                final LoadingDialog ld = new LoadingDialog(context);
                ld.setLoadingText("يرجى الانتظار").show();
                HttpAgent.post(MainActivity.getApi("data/user/report.php"))
                        .setTimeOut(10000)
                        .headers("Content-Type", "application/x-www-form-urlencoded")
                        .withBody("post="+post+"&user="+user+"&time="+time+"&message="+message)
                        .goJson(new JsonCallback() {
                            @Override
                            protected void onDone(boolean success, JSONObject jsonObject) {
                                if (success) {
                                    try {
                                        if (jsonObject.getInt("status") == 1) {
                                            ld.setSuccessText(jsonObject.getString("code")).loadSuccess();
                                        } else {
                                            ld.setFailedText(jsonObject.getString("code")).loadFailed();
                                        }
                                    } catch (JSONException e) {
                                        ld.setFailedText(e.getMessage()).loadFailed();
                                        e.printStackTrace();
                                    }
                                } else {
                                    ld.setFailedText(getErrorMessage()).loadFailed();
                                }
                            }
                        });
            }
        });
        posts.create().show();
    }
    public static String getUsername(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        String data = "";
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            data = obj.getString("username");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static String getPassword(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        String data = "";
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            data = obj.getString("password");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static Boolean isLogin(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        Boolean bln = sharedPref.getBoolean("status", false);
        return bln;
    }
    public static Boolean isAdmin(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        Boolean data = false;
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            if (obj.has("isAdmin")) {
                if (obj.getBoolean("isAdmin")) {
                    data = true;
                } else {
                    data = false;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }
    public static Boolean isPremium(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        Boolean data = false;
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            data = obj.getBoolean("hasPremium");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static String getPremiumColor(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        String data = "";
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            data = obj.getString("premium");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static String getDec(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        String data = "";
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            data = obj.getString("dec");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    public static String getImage(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        String data = "";
        try {
            JSONObject obj = new JSONObject(sharedPref.getString("profile",""));
            data = obj.getString("userimage");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }
    public static void Logout(Context context, Activity activity) {
        AnimeUtil.deleteCache(context);
        SharedPreferences sharedPref = context.getSharedPreferences("profile", Context.MODE_PRIVATE);
        sharedPref.edit().clear().apply();
        AnimeUtil.reActivity(activity,activity.getClass());
    }
    public static void SignUp(MainActivity activity ,Context context) {
        final Dialog dialogs = new Dialog(activity);
        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogs.setContentView(R.layout.regis);
        dialogs.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialogs.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        final Button bt_submit = (Button) dialogs.findViewById(R.id.bt_submit);
        final ImageView profiles = (ImageView) dialogs.findViewById(R.id.profiles);
        imgss =  dialogs.findViewById(R.id.profiles);
        profiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EasyImage.openGallery(activity,0);
            }
        });
        final String[] usernm = {""};
        final String[] email = {""};
        final String[] passw = {""};
        final String[] des = {""};
        ((TextInputEditText) dialogs.findViewById(R.id.username)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                usernm[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ((TextInputEditText) dialogs.findViewById(R.id.email)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                email[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ((TextInputEditText) dialogs.findViewById(R.id.password)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                passw[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ((TextInputEditText) dialogs.findViewById(R.id.des)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                des[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ((TextInputEditText) dialogs.findViewById(R.id.username)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        bt_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (packed) {
                    if (isEmailValid(email[0])) {
                        try {
                            File gpxfile = new File(Environment.getExternalStorageDirectory().getPath(), "text.txt");
                            FileWriter writer = new FileWriter(gpxfile);
                            writer.append(imgs);
                            writer.flush();
                            writer.close();
                            loadingDialog = new LoadingDialog(activity);
                            CONTEXT = context;
                            ACTIVITY = activity;
                            MainActivityClass = activity.getClass();
                            dialogs.dismiss();
                            new UploadToServer.Register().execute(MainActivity.getApi("data/user/regs.php"),gpxfile,usernm[0],passw[0],email[0],System.currentTimeMillis(),des[0]);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(activity,"يجب عليك كتابة البريد الاكتروني بشكل صحيح لعمل حساب",Toast.LENGTH_SHORT).show();
                    }
                } else  {
                    Toast.makeText(activity,"يرجى أختيار صورة",Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialogs.show();
        dialogs.getWindow().setAttributes(lp);
    }
    public static void addBackup(Activity context) {
        SharedPreferences sharedPrefs = context.getSharedPreferences("backuped", Context.MODE_PRIVATE);
        sharedPrefs.edit().putBoolean("backuped", true).apply();
    }
    public static Boolean ifRestored(Activity activity) {
        SharedPreferences sharedPrefs = activity.getSharedPreferences("backuped", Context.MODE_PRIVATE);
        return sharedPrefs.getBoolean("backuped",false);
    }
    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    public static void openProfile(JSONObject obj, Context context) {
        final Dialog dialogs = new Dialog(context);
        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogs.setContentView(R.layout.user);
        dialogs.setCancelable(true);
        final ImageView userimg = dialogs.findViewById(R.id.image);
        final TextView username = dialogs.findViewById(R.id.name);
        final TextView dec = dialogs.findViewById(R.id.dec);
        final ImageView prem = dialogs.findViewById(R.id.prem);
        final LinearLayout userpost = dialogs.findViewById(R.id.userpostlist);
        username.setTextColor(Color.parseColor("#FFFFFF"));
        prem.setVisibility(View.GONE);
        try {
            Glide.with(context).load(Uri.parse(obj.getString("icon"))).into(userimg);
            username.setText(obj.getString("name"));
            dec.setText(obj.getString("dec"));
            if (Boolean.parseBoolean(obj.getString("hasPremium"))) {
                username.setTextColor(Color.parseColor(obj.getString("premium")));
                prem.setVisibility(View.VISIBLE);
            } else {
                username.setTextColor(Color.parseColor("#FFFFFF"));
                prem.setVisibility(View.GONE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //postlist
        try {
            if (!obj.getJSONArray("post").toString().contains("null")) {
                try {
                    userpost.removeAllViews();
                    JSONArray jsonResults = new JSONArray(obj.getJSONArray("post").toString());
                    for (int i = 0; i < jsonResults.length(); i++) {
                        try {
                            JSONObject fullpost = new JSONObject();
                            fullpost = jsonResults.getJSONObject(i);
                            View views = LayoutInflater.from(context).inflate(R.layout.post_list, null);
                            final CircleImageView userimage = views.findViewById(R.id.post_image);
                            final ImageView premium = views.findViewById(R.id.post_premium);
                            final TextView usernames = views.findViewById(R.id.post_user);
                            final TextView time = views.findViewById(R.id.post_time);
                            final TextView totalcmd = views.findViewById(R.id.totalcmd);
                            final TextView post = views.findViewById(R.id.post_text);
                            final ImageButton menu = views.findViewById(R.id.post_menu);
                            final Button isfire = views.findViewById(R.id.isfire);
                            final Button showmore = views.findViewById(R.id.showmorebtn);
                            final ImageButton opencmd = views.findViewById(R.id.opencmd);
                            final CardView frameLayout = views.findViewById(R.id.blurs);
                            final LinearLayout anime = views.findViewById(R.id.post_anime);
                            final LinearLayout giflinear = views.findViewById(R.id.giflinear);
                            final ImageView gifimage = views.findViewById(R.id.gifimage);
                            final Boolean[] isShowing = {false};
                            int finalI1 = i;
                            opencmd.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    try {
                                        openCMD(jsonResults.getJSONObject(finalI1).getString("id"),jsonResults.getJSONObject(finalI1).getJSONArray("commant"),context);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                            if (jsonResults.getJSONObject(i).getString("hasImage").isEmpty()) {
                                giflinear.setVisibility(View.GONE);
                            } else {
                                giflinear.setVisibility(View.VISIBLE);
                                if (jsonResults.getJSONObject(i).getString("hasImage").contains("gif")) {
                                    Glide.with(context).asGif().load(Uri.parse(jsonResults.getJSONObject(i).getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                                } else {
                                    Glide.with(context).load(Uri.parse(jsonResults.getJSONObject(i).getString("hasImage"))).apply(RequestOptions.bitmapTransform(new RoundedCorners(8))).into(gifimage);
                                }
                            }
                            totalcmd.setText(String.valueOf(jsonResults.getJSONObject(i).getJSONArray("commant").length()));
                            showmore.setVisibility(View.GONE);
                            isfire.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    frameLayout.setVisibility(View.GONE);
                                    post.setVisibility(View.VISIBLE);
                                }
                            });
                            if (jsonResults.getJSONObject(i).getBoolean("hasFire")) {
                                frameLayout.setVisibility(View.VISIBLE);
                                post.setVisibility(View.GONE);
                            } else {
                                frameLayout.setVisibility(View.GONE);
                            }
                            usernames.setText(jsonResults.getJSONObject(i).getString("username"));
                            if (jsonResults.getJSONObject(i).getBoolean("hasPremium")) {
                                usernames.setTextColor(Color.parseColor(jsonResults.getJSONObject(i).getString("premium")));
                                premium.setVisibility(View.VISIBLE);
                            } else {
                                usernames.setTextColor(Color.parseColor("#ffffff"));
                                premium.setVisibility(View.GONE);
                            }
                            time.setText(AnimeUtil.getTimeAgo(jsonResults.getJSONObject(i).getString("time")));
                            int line = getLineCount(jsonResults.getJSONObject(i).getString("post"));
                            if (line > 14) {
                                showmore.setVisibility(View.VISIBLE);
                            }
                            String flpost = jsonResults.getJSONObject(i).getString("post");
                            showmore.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (isShowing[0]) {
                                        post.setText(flpost);
                                        isShowing[0] = false;
                                        post.setMaxLines(10);
                                        showmore.setText("قرائة الكل");
                                    } else {
                                        post.setText(flpost+newLine());
                                        isShowing[0] = true;
                                        post.setMaxLines(Integer.MAX_VALUE);
                                        post.setText(post.getText().toString() + "");
                                        showmore.setText("أخفاء");
                                    }
                                }
                            });
                            post.setText(jsonResults.getJSONObject(i).getString("post"));
                            final String postid = jsonResults.getJSONObject(i).getString("id");
                            Glide.with(context).load(Uri.parse(jsonResults.getJSONObject(i).getString("userimage"))).into(userimage);
                            int finalI = i;
                            if (jsonResults.getJSONObject(i).getBoolean("hasAnime")) {
                                for (int is = 0; is <jsonResults.getJSONObject(i).getJSONArray("anime").length(); is++) {
                                    View viewss = LayoutInflater.from(context).inflate(R.layout.otherlist, null);
                                    final ImageView images = (ImageView) viewss.findViewById(R.id.exampleimg);
                                    final LinearLayout linear2 = (LinearLayout) viewss.findViewById(R.id.linear2);
                                    final ProgressBar loadings = (ProgressBar) viewss.findViewById(R.id.prof);
                                    final TextView textview2 = (TextView) viewss.findViewById(R.id.exampletxt2);
                                    textview2.setText(jsonResults.getJSONObject(i).getJSONArray("anime").getJSONObject(i).getString("name"));
                                    int finalIs = is;
                                    linear2.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            try {
                                                final LoadingDialog dl = new LoadingDialog(context);
                                                dl.setLoadingText("يرجى الانتظار");
                                                dl.show();
                                                HttpAgent.get(MainActivity.getApi("data/inf.php?id="+jsonResults.getJSONObject(finalI).getJSONArray("anime").getJSONObject(finalIs).getString("id")))
                                                        .setTimeOut(10000)
                                                        .goString(new StringCallback() {
                                                            @Override
                                                            protected void onDone(boolean success, String stringResults) {
                                                                dl.close();
                                                                if (success){
                                                                    try {
                                                                        if (imageToBitmap.DDA(stringResults).contains("error make image")) {
                                                                            MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                            context.startActivity(new Intent(context, InfoActivity.class));
                                                                        } else {
                                                                            MainActivity.INFOS = imageToBitmap.DDA(stringResults);
                                                                            context.startActivity(new Intent(context, InfoActivity.class));
                                                                        }
                                                                    } catch (Exception e) {
                                                                        e.printStackTrace();
                                                                        Toast.makeText(context,"توجد مشكلة أو صيانة في السيرفر يتم العمل عليها حاليا يرجى الانتظار",Toast.LENGTH_SHORT).show();
                                                                    }
                                                                } else {
                                                                    Toast.makeText(context,"توجد مشكلة في الشبكة تحقق منها وأعد المحاولة",Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                    Glide.with(context)
                                            .load(Uri.parse(jsonResults.getJSONObject(i).getJSONArray("anime").getJSONObject(i).getString("image")))
                                            .apply(RequestOptions.bitmapTransform(new RoundedCorners(8)))
                                            .listener(new RequestListener<Drawable>() {
                                                @Override
                                                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                                    return false;
                                                }
                                                @Override
                                                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                                    loadings.setVisibility(View.GONE);
                                                    return false;
                                                }
                                            })
                                            .into(images);
                                    viewss.setId(i);
                                    anime.addView(viewss);
                                }
                            }
                            final String users = jsonResults.getJSONObject(i).getString("username");
                            JSONObject finalFullpost = fullpost;
                            menu.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    PopupMenu popup = new PopupMenu(context, v);
                                    MenuInflater inflater = popup.getMenuInflater();
                                    inflater.inflate(R.menu.menu_cmd, popup.getMenu());
                                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                        @Override
                                        public boolean onMenuItemClick(MenuItem item) {
                                            if (item.getItemId() == popup.getMenu().getItem(1).getItemId()) {

                                            } else {
                                                AccountUtil.reportPost(context,String.valueOf(System.currentTimeMillis()),AccountUtil.getUsername(context), finalFullpost.toString(),users);
                                            }
                                            return false;
                                        }
                                    });
                                    popup.show();
                                }
                            });
                            views.setId(i);
                            userpost.addView(views);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //endpostlist
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialogs.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        final ImageButton bt_submit = (ImageButton) dialogs.findViewById(R.id.sendcmd);
        final LinearLayout lists = (LinearLayout) dialogs.findViewById(R.id.cmd);
        dialogs.show();
        dialogs.getWindow().setAttributes(lp);
    }
    public static void updateAcc(MainActivity activity ,Context context) {
        final Dialog dialogs = new Dialog(activity);
        dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogs.setContentView(R.layout.register);
        dialogs.setCancelable(true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialogs.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        final TextView titlereg = dialogs.findViewById(R.id.titlereg);
        titlereg.setText("تعديل بيانات الحساب");
        final Button bt_submit = (Button) dialogs.findViewById(R.id.bt_submit);
        bt_submit.setText("تعديل");
        final ImageView profiles = (ImageView) dialogs.findViewById(R.id.profiles);
        imgss =  dialogs.findViewById(R.id.profiles);
        profiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EasyImage.openGallery(activity,0);
            }
        });

        final String[] usernm = {""};
        final String[] newpass = {""};
        final String[] passw = {""};
        final String[] des = {""};

        TextInputEditText text = dialogs.findViewById(R.id.email);
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        text.setHint("كلمة المرور الجديدة");
        ((TextInputEditText) dialogs.findViewById(R.id.email)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                newpass[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ((TextInputEditText) dialogs.findViewById(R.id.password)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                passw[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        ((TextInputEditText) dialogs.findViewById(R.id.des)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bt_submit.setEnabled(!s.toString().trim().isEmpty());
                des[0] = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        bt_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (packed) {
                    try {
                        File gpxfile = new File(Environment.getExternalStorageDirectory().getPath(), "text.txt");
                        FileWriter writer = new FileWriter(gpxfile);
                        writer.append(imgs);
                        writer.flush();
                        writer.close();
                        loadingDialog = new LoadingDialog(activity);
                        CONTEXT = context;
                        ACTIVITY = activity;
                        MainActivityClass = activity.getClass();
                        dialogs.dismiss();
                        new UploadToServer.UploadFileAsync().execute(MainActivity.getApi("data/user/edits.php"),gpxfile,AccountUtil.getUsername(context),passw[0],des[0],newpass[0],context,activity);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else  {
                    Toast.makeText(activity,"يرجى أختيار صورة",Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialogs.show();
        dialogs.getWindow().setAttributes(lp);
    }
}
